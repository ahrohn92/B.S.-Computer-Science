<?php
// Connects to Wamp Database
include_once 'Includes/connectDB.php';

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}	

$newUserName = mysqli_real_escape_string($conn, $newUserName);
$newPassWord = mysqli_real_escape_string($conn, $newPassWord);

// Checks if Username and Password are Original
$sql_1 = "SELECT * FROM players WHERE Username='$newUserName';";
$sql_2 = "SELECT * FROM players WHERE Password='$newPassWord';";

if (mysqli_num_rows(mysqli_query($conn, $sql_1)) > 0) {
	$uniqueUserCheck = false;
	
} else if (mysqli_num_rows(mysqli_query($conn, $sql_2)) > 0) {
	$uniquePassCheck = false;
	
} else {
	$sql_3 = "INSERT INTO Players (Username, Password, HighScore) VALUES ('$newUserName', '$newPassWord', '0');";
	$uniqueUserCheck = true;
	$uniquePassCheck = true;
}

$que_0 = mysqli_real_escape_string($conn, $que_0);
$ans_0 = mysqli_real_escape_string($conn, $ans_0);
$que_1 = mysqli_real_escape_string($conn, $que_1);
$ans_1 = mysqli_real_escape_string($conn, $ans_1);
$que_2 = mysqli_real_escape_string($conn, $que_2);
$ans_2 = mysqli_real_escape_string($conn, $ans_2);

// Insert Security Questions
$sql_4 = "INSERT INTO securityquestions (Username, SecurityQuestion_1, SecurityAnswer_1, SecurityQuestion_2, SecurityAnswer_2, SecurityQuestion_3, SecurityAnswer_3) VALUES ('$newUserName', '$que_0', '$ans_0', '$que_1', '$ans_1', '$que_2', '$ans_2');";


// Check for Errors
if(mysqli_query($conn, $sql_3)){
	echo "";
} else{
	echo mysqli_error($conn);
}

if(mysqli_query($conn, $sql_4)){
	echo "";
} else{
	echo mysqli_error($conn);
}

// Closes Connection to Database
mysqli_close($conn);
?>