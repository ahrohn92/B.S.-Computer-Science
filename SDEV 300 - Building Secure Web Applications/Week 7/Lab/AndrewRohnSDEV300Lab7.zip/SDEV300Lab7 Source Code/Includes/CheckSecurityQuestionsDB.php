<?php

$userName = $_SESSION['appUserName'];

// Connects to Wamp Database
$sqlServerName = "localhost";
$sqlUserName = "wamp_user";
$sqlPassWord = "user4wamp";
$sqlDB = "wamp";

// Creates Connection with mysql
$conn = mysqli_connect($sqlServerName, $sqlUserName, $sqlPassWord, $sqlDB);

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}
$securityQA = array(6);

$sql = "SELECT * FROM securityquestions WHERE Username='$userName';";

$result = mysqli_query($conn, $sql) or die(mysqli_error());

	while ($row = mysqli_fetch_assoc($result)) {
		$securityQA[0] = $row['SecurityQuestion_1'];
		$securityQA[1] = $row['SecurityAnswer_1'];
		$securityQA[2] = $row['SecurityQuestion_2'];
		$securityQA[3] = $row['SecurityAnswer_2'];
		$securityQA[4] = $row['SecurityQuestion_3'];
		$securityQA[5] = $row['SecurityAnswer_3'];
	}	

// Closes Connection to Database
mysqli_close($conn);
?>