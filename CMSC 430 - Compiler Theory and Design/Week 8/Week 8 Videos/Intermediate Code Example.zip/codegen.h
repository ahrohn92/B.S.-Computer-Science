typedef char* CharPtr;
enum Operators {LESS, ADD, MULTIPLY, AND};

CharPtr emit(Operators opCode, CharPtr left, CharPtr right);