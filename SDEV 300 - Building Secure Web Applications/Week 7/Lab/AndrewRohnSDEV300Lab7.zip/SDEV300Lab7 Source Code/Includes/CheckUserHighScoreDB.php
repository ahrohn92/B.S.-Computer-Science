<?php
// Connects to Wamp Database
include_once 'Includes/connectDB.php';

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}

$userName = $_SESSION['appUserName'];
$userName = mysqli_real_escape_string($conn, $userName);

$sql = "SELECT HighScore FROM players WHERE Username='$userName';";

$result = mysqli_query($conn, $sql) or die(mysqli_error());

while ($row = mysqli_fetch_assoc($result)) {
	$userCurrentHighScore[0] = $row['HighScore'];
}

// Check for Errors
if(mysqli_query($conn, $sql)){
	echo "";
} else{
	echo mysqli_error($conn);
}

// Closes Connection to Database
mysqli_close($conn);
?>