@extends('layouts.app')
@section('content')
<div class="container">
    <shuffler></shuffler>
    <h1>Home Page</h1>
</div>
@endsection
