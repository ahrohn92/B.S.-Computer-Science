<?php
session_start();

// Connects to Wamp Database
include_once 'Includes/connectDB.php';

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}	

// Sanitize String
$deleteUserName = mysqli_real_escape_string($conn, $_SESSION['appUserName']);

// Prepared Deletion Statement #1
$sql_1 = "DELETE FROM players WHERE Username=?;";
$stmt = $conn->prepare($sql_1);			
$stmt->bind_param("s", $deleteUserName);
$stmt->execute();

//Clean-up				
$stmt->close(); 

// Prepared Deletion Statement #2
$sql_2 = "DELETE FROM securityquestions WHERE Username=?;";
$stmt = $conn->prepare($sql_2);			
$stmt->bind_param("s", $deleteUserName);
$stmt->execute();

//Clean-up				
$stmt->close(); 

// Closes Connection to Database
mysqli_close($conn);

// Takes user back to login page after deletion of account
include('loginPage.php');
echo "<p align='center'><b>Your account was successfully deleted.</b></p>";
?>