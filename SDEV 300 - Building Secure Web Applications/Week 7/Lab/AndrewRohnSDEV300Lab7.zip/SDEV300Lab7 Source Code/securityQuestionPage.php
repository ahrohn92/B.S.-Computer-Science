<!DOCTYPE HTML>
<html>
<?php
$userName = $_POST["username"];
$passWord = $_POST["password"];

session_start();
$_SESSION['appUserName'] = $userName;
$_SESSION['appPassWord'] = $passWord;

if ($_SESSION['appUserName'] == '' || $_SESSION['appPassWord'] == '') {
	include('loginPage.php');
	echo "<p align='center'><b>Please enter your username and password to login.</b></p>";
} else {
	// Check if login info is in database
	include_once 'Includes/CheckPlayerDB.php';
	if (($userCheck == false) || ($passCheck == false)) {
		include('loginPage.php');
		echo "<p align='center'><b>Incorrect Username or Password.</b></p>";
	} else {
		include_once 'Includes/CheckSecurityQuestionsDB.php';
		
		// Generates Random Security Question to Complete Login
		$numSelect = rand(0,2);

		// Decides Random Security Questions
		if ($numSelect == 0) {
			$randomQuestion = $securityQA[0];
			$randomAnswer = $securityQA[1];
		}
		if ($numSelect == 1) {
			$randomQuestion = $securityQA[2];
			$randomAnswer = $securityQA[3];
		}
		if ($numSelect == 2) {
			$randomQuestion = $securityQA[4];
			$randomAnswer = $securityQA[5];
		}
		
		$_SESSION['appSecurityQuestion'] = $randomQuestion;
		$_SESSION['appSecurityAnswer'] = $randomAnswer;
?>


<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
	<title>Multiplication Complication &trade; - Security Question Page</title>
</head>
<body>
<form name='loginreturn' method='post' action='loginPage.php'> 
			<input name='loginreturnbutton' type='submit' value='Return to Login Page'>
</form>
<h1 align="center">Security Question</h1>
<form name="randomsecurityquestion" method="post" action="gamePage.php"> 
	<table align="center" border="5">
		<tr>
			<th><?php echo $randomQuestion; ?></th>
		</tr>
		<tr>
			<td><input name="randomquestionanswer"<?php echo $i; ?>" type="text" size="50"></td>
		</tr>
		<tr>
			<td align="center"><input name="submitbutton" type="submit" value="Submit"></td>
		</tr>
	</table>
</form>
</body>
<?php
		}
	}
?>
</html>