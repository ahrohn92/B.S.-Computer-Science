import java.util.*;
import javax.swing.JOptionPane;

/*
 * Course:  	CMSC 451
 * File: 		BenchmarkSorts.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 April 2019
 * Purpose: 	Generates 50 random data sets of various sizes and sends them to be sorted. Checks to see if the
 * 				data sets were properly sorted and uses the returned values to calculate averages and coefficients
 * 				of variance for both the number of critical operations and execution time for both iterative and 
 * 				recursive merge sorting functions. Stores the results and sends them to main method to populate a JTable.
 */

public class BenchmarkSorts {
	
	// Instance Variables
    private static int NUMBER_OF_DATA_SETS = 50;
    private int[] randomDataSet;
    private int[] sortedDataSet;
    private double[] iterativeCountArray;
    private double[] recursiveCountArray;
    private double[] iterativeTimeArray;
    private double[] recursiveTimeArray;
    private double totalIterativeCount, totalRecursiveCount;
    private double totalIterativeTime, totalRecursiveTime;
    private double [] iterativeCountAverages;
    private double [] iterativeTimeAverages;
    private double [] recursiveCountAverages;
    private double [] recursiveTimeAverages;
    private double [] iterativeCountCOVs;
    private double [] iterativeTimeCOVs;
    private double [] recursiveCountCOVs;
    private double [] recursiveTimeCOVs;
    private int index;
    
    // ArrayList of Results
    private ArrayList<Double> results = new ArrayList<>();
    
    // ArrayLists for Displaying Data in Table
    private ArrayList<Double> dataSetResults;
    
    // MergeSort() Class Object
    private MergeSort mergeSort = new MergeSort();
    
    // Constructor
    public BenchmarkSorts(int[] dataSetSizes) {
  
    	// Initializes Arrays for Storing Averages & COVs
    	iterativeCountAverages = new double[dataSetSizes.length];
        iterativeTimeAverages = new double[dataSetSizes.length];
        recursiveCountAverages = new double[dataSetSizes.length];
        recursiveTimeAverages = new double[dataSetSizes.length];
    	iterativeCountCOVs = new double[dataSetSizes.length];
        iterativeTimeCOVs = new double[dataSetSizes.length];
        recursiveCountCOVs = new double[dataSetSizes.length];
        recursiveTimeCOVs = new double[dataSetSizes.length];
        
        // Creates benchmarks based on the input array size
        for (int i = 0; i < dataSetSizes.length; i++) {
        	
        	dataSetResults = new ArrayList<>();
        	index = 0;
        	
        	// Initializes Arrays for Storing Count and Time
            iterativeCountArray = new double[NUMBER_OF_DATA_SETS];
            iterativeTimeArray = new double[NUMBER_OF_DATA_SETS];
            recursiveCountArray = new double[NUMBER_OF_DATA_SETS];
            recursiveTimeArray = new double[NUMBER_OF_DATA_SETS];
        	
        	// Resets Count and Time Totals
            totalIterativeCount = 0;
            totalIterativeTime = 0;
            totalRecursiveCount = 0;
            totalRecursiveTime = 0;
            
        	// Generates Random Data Set of Size n
        	for (int j = 0; j  < NUMBER_OF_DATA_SETS; j++) {
        		randomDataSet = new int[dataSetSizes[i]];
        		Random rand = new Random();
        		for (int k = 0; k < dataSetSizes[i]; k++) {
        			// With Values from 0 to 1000
        			randomDataSet[k] = rand.nextInt(1000);
        		}
            	try {
            		runSorts();
            	} catch (UnsortedException e) {
            		JOptionPane.showMessageDialog(null, 
            				"One or more data set(s) could not be sorted correctly",
                			"Error", JOptionPane.ERROR_MESSAGE);
            	}
        	}
        	
        	// Arrays for Storing Averages
        	iterativeCountAverages[i] = totalIterativeCount / NUMBER_OF_DATA_SETS;
        	iterativeTimeAverages[i] = totalIterativeTime / NUMBER_OF_DATA_SETS;
        	recursiveCountAverages[i] = totalRecursiveCount / NUMBER_OF_DATA_SETS;
        	recursiveTimeAverages[i] = totalRecursiveTime / NUMBER_OF_DATA_SETS;
        	
        	// Arrays for Storing Coefficients of Variance
        	iterativeCountCOVs[i] = coefficientOfVariance(iterativeCountArray, iterativeCountAverages[i]);
        	iterativeTimeCOVs[i] = coefficientOfVariance(iterativeTimeArray, iterativeTimeAverages[i]);
        	recursiveCountCOVs[i] = coefficientOfVariance(recursiveCountArray, recursiveCountAverages[i]);
        	recursiveTimeCOVs[i] = coefficientOfVariance(recursiveTimeArray, recursiveTimeAverages[i]);
        }
        displayReport(dataSetSizes.length);
    }

    // Runs Iterative and Recursive Merge Sorting Function and Returns Analytics
    private void runSorts() throws UnsortedException {
    	
    	// Makes Copy of Data Set So Recursive Function Doesn't Inherit a Sorted Array
    	int [] randomDataSetCopy = Arrays.copyOf(randomDataSet, randomDataSet.length);
    	
        // Runs Iterative Merge Sort Function
        sortedDataSet = mergeSort.iterativeSort(randomDataSet);
        
        // Checks if Data Set is Sorted Properly
        checkSortedDataSet(sortedDataSet);
        
        // Retrieves Count and Time Values for Iterative Sort
        double count = mergeSort.getCount();
        double time = mergeSort.getTime();
        
        // Stores Iterative Count and Time Values
        iterativeCountArray[index] = count;
        iterativeTimeArray[index] = time;
        totalIterativeCount += count;
        totalIterativeTime += time;
        
        // Runs Recursive Merge Sort Function
        sortedDataSet = mergeSort.recursiveSort(randomDataSetCopy);
        
        // Checks if Data Set is Sorted Properly
        checkSortedDataSet(sortedDataSet);
        
        // Retrieves Count and Time Values for Recursive Sort
        count = mergeSort.getCount();
        time = mergeSort.getTime();

        // Stores Recursive Count and Time Values
        recursiveCountArray[index] = count;
        recursiveTimeArray[index] = time;
        totalRecursiveCount += count;
        totalRecursiveTime += time;
        
        index++;
    }
    
    // Method Returns Coefficient of Variance of Array
    private double coefficientOfVariance(double[] values, double mean) {
    	
    	double standardDeviation = 0;
    	double coefficientOfVariance = 0;
    	double temp = 0;
    	
    	for (int i = 0; i < values.length; i++) {
    		temp += Math.pow((values[i] - mean), 2);
    	}
    	
    	standardDeviation = Math.sqrt(temp / (values.length - 1));
    	coefficientOfVariance = standardDeviation / mean;
    	
    	return coefficientOfVariance;
    }
    
    // Method Checks to See if Data Set Was Sorted Correctly
    private void checkSortedDataSet(int[] sortedDataSet) throws UnsortedException {
        for (int i = 0; i < sortedDataSet.length - 1; i++) {
            if (sortedDataSet[i] > sortedDataSet[i + 1]) {
                throw new UnsortedException("The following data set was not correctly sorted:\n"
            +Arrays.toString(sortedDataSet)+"\nIncorrect order at:\n"+sortedDataSet[i]+" at index"
            		+ " "+i+" and "+sortedDataSet[i + 1]+" at index "+(i + 1));
            }
        }
    }
    
    // Calculates Averages and COVs and Stores Results in ArrayList
    private void displayReport(int numSizes) {
    	
    	// Adds Results to ArrayList
    	for (int i = 0; i < numSizes; i++) {
    		dataSetResults.add(iterativeCountAverages[i]);
    		dataSetResults.add(iterativeCountCOVs[i]);
    		dataSetResults.add(iterativeTimeAverages[i]);
    		dataSetResults.add(iterativeTimeCOVs[i]);
    		dataSetResults.add(recursiveCountAverages[i]);
    		dataSetResults.add(recursiveCountCOVs[i]);
    		dataSetResults.add(recursiveTimeAverages[i]);
    		dataSetResults.add(recursiveTimeCOVs[i]);
    	}
        setResults(dataSetResults);
    }
    
    // Setter Method for Results
    private void setResults(ArrayList<Double> dataSetResults) {
    	for (double result : dataSetResults) {
    		this.results.add(result);
    	}
    }
    
    // Getter Method for Results
    public ArrayList<Double> getResults() {
    	return results;
    }
}