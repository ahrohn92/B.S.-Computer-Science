import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;

/*
 * Course:  	CMSC 350
 * File: 		OperatorNodes.java
 * Author: 		Andrew H. Rohn
 * Date: 		18 November 2018
 * Purpose: 	Creates the operator nodes used in the arithmetic expression tree. Also pairs operand nodes with an operator node
 */

public class OperatorNodes implements TreeNodes {

    // Instance Variables
	private File file = new File("Three Address.txt"); // Creates text file
    private String operator;
    private TreeNodes rightOperandNode, leftOperandNode;
    private static int registerCount;   // register count for 3-address code
    
    // Localizes Variables
    OperatorNodes(String operator, TreeNodes rightOperandNode, TreeNodes leftOperandNode) {
        this.operator = operator;
        this.rightOperandNode = rightOperandNode;
        this.leftOperandNode = leftOperandNode;
        operatorInstructionEval(operator);
    }

    // Traverses arithmetic tree in post order
    public String traversePostOrder() throws IOException {
        String leftOperand = leftOperandNode.traversePostOrder();
        String rightOperand = rightOperandNode.traversePostOrder();
        String operatorInstruction = operatorInstructionEval(this.operator);

        String register = "R"+registerCount++;

        // Creates an instruction line to be written into Three Address file
        String instructionLine = operatorInstruction+" "+register+" "+leftOperand+" "+rightOperand;
        writeToFile(instructionLine);

        return register;
    }

    // Pairs operator node with operand nodes to make infix expression
    public String traverseInOrder() {
        return "( "+leftOperandNode.traverseInOrder()+" "+operator+" "+rightOperandNode.traverseInOrder()+" )";
    }
    
    // Writes a line in the Three Address text file
    private void writeToFile(String line) throws IOException {
    	
        BufferedWriter bufferedWriter = new BufferedWriter(new FileWriter(file,true));
        
        bufferedWriter.write(line);
        bufferedWriter.newLine();
        bufferedWriter.close();
    }
    
    // Method creates three letter instruction for operator
    private String operatorInstructionEval(String operator) {
        String instruction = null;

        switch (operator) {
            case "+":
            	instruction = "Add";
                break;
            case "-":
            	instruction = "Sub";
                break;
            case "*":
            	instruction = "Mul";
                break;
            case "/":
            	instruction = "Div";
                break;
        }
        return instruction;
    }
    
    // Helper Method for traversePostOrder(), new traversal of tree
    public void newTraversal() throws IOException {
    	traversePostOrder(); // Initiates post order traversal of tree
    	registerCount = 0;  // Starts register count at 0
    }
}