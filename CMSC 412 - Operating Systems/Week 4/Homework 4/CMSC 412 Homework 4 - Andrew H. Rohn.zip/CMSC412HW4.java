import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Scanner;

/*
 * Course:  	CMSC 412
 * File: 		CMSC412HW4.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 Sep 2019
 * Purpose: 	This program reads input from a text file and organizes it into different data structures. 
 * 				The data is then used to illustrate the solution of Banker's Algorithm for deadlock avoidance.
 */

public class CMSC412HW4 {
	
	// Global Variables
	private ArrayList<String> processes = new ArrayList<String>();
	private ArrayList<Integer> resources = new ArrayList<Integer>();
	private ArrayList<Integer> allocationData = new ArrayList<Integer>();
	private ArrayList<Integer> maxData = new ArrayList<Integer>();
	private int[] availableResources;
	private int[][] allocationMatrix;
	private int[][] maxMatrix;
	private int[][] needMatrix;
	private boolean[] processesCompleted;
	private static String safeSequence = "";

	// Constructor, Handles File Input
	public CMSC412HW4() {
		
		// Opens File
		Scanner inputScanner = new Scanner(System.in);
		System.out.println("Enter the name of the input file (ex: input.txt):");
		String file = inputScanner.next();
		inputScanner.close();
		
		// Assigns Data to Variables
		int lineNumber = 1;
		try {
			Scanner fileScanner = new Scanner(new File(file));
			while (fileScanner.hasNextLine()) {
				String line = fileScanner.nextLine();
				Scanner lineScanner = new Scanner(line);
				while (lineScanner.hasNext()) {
					if (lineNumber == 1) {
						processes.add(lineScanner.next());
					} else if (lineNumber == 2) {
						resources.add(lineScanner.nextInt());
					} else if (lineNumber == 3) {
						allocationData.add(lineScanner.nextInt());
					} else if (lineNumber == 4) {
						maxData.add(lineScanner.nextInt());
					}
				}
				lineScanner.close();
				lineNumber++;
			}
			fileScanner.close();
		} catch (FileNotFoundException e) {
			System.out.println("Could read chosen file");
			e.printStackTrace();
		}
	}
	
	// Creates Data Structures
	private void createDataStructures() {
		
		// Initial Process Completion
		processesCompleted = new boolean[processes.size()];
		for (int i = 0; i < processesCompleted.length; i++) {
			processesCompleted[i] = false;
		}
		
		// Creates Allocation Matrix
		allocationMatrix = new int[processes.size()][resources.size()];
		int index = 0;
		for (int i = 0; i < processes.size(); i++) {
			for (int j = 0; j < resources.size(); j++) {
				allocationMatrix[i][j] = allocationData.get(index);
				index++;
			}
		}
		
		// Calculates Initial Available Resources
		availableResources = new int[resources.size()];
		for (int i = 0; i < availableResources.length; i++) {
			availableResources[i] = resources.get(i);
		}
		for (int i = 0; i < processes.size(); i++) {
			for (int j = 0; j < resources.size(); j++) {
				availableResources[j] -= allocationMatrix[i][j];
			}
		}
		
		// Creates Max Matrix
		maxMatrix = new int[processes.size()][resources.size()];
		index = 0;
		for (int i = 0; i < processes.size(); i++) {
			for (int j = 0; j < resources.size(); j++) {
				maxMatrix[i][j] = maxData.get(index);
				index++;
			}
		}
		
		// Creates Need Matrix (Max - Allocation = Need)
		needMatrix = new int[processes.size()][resources.size()];
		for (int i = 0; i < processes.size(); i++) {
			for (int j = 0; j < resources.size(); j++) {
				needMatrix[i][j] = maxMatrix[i][j] - allocationMatrix[i][j];
			}
		}
	}
	
	// Prints Input Data
	private void printInputData() {
		
		// Prints Data
		System.out.println("\n"+processes.size()+" Processes = "+processes+"\n");
		System.out.println(resources.size()+" Resources = "+resources+"\n");
		
		// Prints Allocated Matrix
		System.out.println("Allocation Matrix:\n");
		printMatrix(allocationMatrix);
		
		System.out.println("Available Resources After Allocation = "+Arrays.toString(availableResources)+"\n");
		
		// Prints Max Matrix
		System.out.println("Max Matrix:\n");
		printMatrix(maxMatrix);
		
		System.out.println("Need Matrix:\n");
		printMatrix(needMatrix);
	}
	
	// Prints Matrices
	private void printMatrix(int[][] matrix) {
		String output = "";
		for (int i = 0; i < matrix.length; i++) {
			for (int j = 0; j < matrix[i].length; j++) {
				if (j == matrix[i].length - 1) {
					output += matrix[i][j]+"\n";
				} else {
					output += matrix[i][j]+" ";
				}
			}
		}
		System.out.println(output);
	}
	
	// Recursive Function That Determines Safe Sequence
	private void determineSafeSequence() {
		for (int i = 0; i < processesCompleted.length; i++) {
			if (processesCompleted[i] == false) {
				boolean flag = true;
				for (int j = 0; j < needMatrix[i].length; j++) {
					if (needMatrix[i][j] > availableResources[j]) {
						flag = false;
					}
				}
				if (flag == true) {
					for (int j = 0; j < availableResources.length; j++) {
						availableResources[j] += allocationMatrix[i][j];
					}
					System.out.println("Process "+processes.get(i)+" completed");
					System.out.println("Resources Available: "+Arrays.toString(availableResources)+"\n");
					safeSequence += processes.get(i)+" ";
					processesCompleted[i] = true;
				}
			}
		}
		for (int i = 0; i < processesCompleted.length; i++) {
			if (processesCompleted[i] == false) {
				determineSafeSequence();
			}
		}
	}
    
	// Main Method
	public static void main(String args[]) {
		
		CMSC412HW4 main = new CMSC412HW4();
		main.createDataStructures();
		main.printInputData();
		
		// Determines Safe Sequence
		System.out.println("Determination of Safe Sequence:\n");
		main.determineSafeSequence();
		System.out.println("Safe Sequence: "+safeSequence);
	}
}
