
use wamp;

/*
	TABLE CREATION
*/

-- Creation of Players Table
CREATE TABLE Players (
	Username varchar(30) not null primary key,
	Password varchar(100) not null,
	HighScore int(6) not null
);

-- Creation of SecurityQuestions Table
CREATE TABLE SecurityQuestions (
	Username varchar(30) not null primary key,
	SecurityQuestion_1 varchar(100) not null,
	SecurityAnswer_1 varchar(100) not null,
	SecurityQuestion_2 varchar(100) not null,
	SecurityAnswer_2 varchar(100) not null,
	SecurityQuestion_3 varchar(100) not null,
	SecurityAnswer_3 varchar(100) not null
);

-- Population of Players Table
insert into Players values('ahrohn92', 'Reality5!', '0');

-- Population of Players Table
insert into SecurityQuestions values('ahrohn92', 'What is your favorite color?', 'Blue', 
'What city was your father born in?', 'Tulare', 'What was the name of your first pet?', 'Max');
