<?php
// DB CONNNECTION (CAN BE MADE INTO SEPERATE FILE LATER!!!!!)
$sqlServerName = "localhost";
$sqlUserName = "wamp_user";
$sqlPassWord = "user4wamp";
$sqlDB = "wamp";

// Creates Connection with mysql
$conn = mysqli_connect($sqlServerName, $sqlUserName, $sqlPassWord, $sqlDB);
?>