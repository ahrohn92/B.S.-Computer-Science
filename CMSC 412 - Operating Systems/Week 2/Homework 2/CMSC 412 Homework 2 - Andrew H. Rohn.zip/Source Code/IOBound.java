import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;

/*
 * Course:  	CMSC 412
 * File: 		IOBound.java
 * Author: 		Andrew H. Rohn
 * Date: 		1 Sep 2019
 * Purpose: 	This class uses a distinct thread to create an output text file in the local
 * 				directory and prints "output_X" to the file 1000 Times. The run time of the 
 * 				thread is returned to the Controller class.
 */

public class IOBound implements Runnable {

	// Instance Variables
	private int threadNumber;
	private long startTime, runTime;
	private boolean isFinished = false;
	private PrintWriter writer;
	
	// Constructor
	public IOBound(int threadNumber) {
		this.threadNumber = threadNumber;
		
		// Creates File for IOBound Output
		try {
			File file = new File("output_"+threadNumber+".txt");
			if (!file.exists()) {
				file.createNewFile();
			}
			writer = new PrintWriter(file);
		} catch (IOException e) {
			e.printStackTrace();
		}
	}

	// Thread's Executable Code
	public void run() {
		
		System.out.println("IO Bound Thread #"+threadNumber+" has started");
		startTime = System.nanoTime(); // Start Time
		
		// Prints "output_X" to Text File 1000 Times
		for (int i = 0; i < 1000; i++) {
			writer.append("output_"+threadNumber+" ");
		}
		writer.close(); // Closes PrintWriter
		
		runTime = System.nanoTime() - startTime; // Run Time
		System.out.println("IO Bound Thread #"+threadNumber+" has ended");
		isFinished = true;
	}
	
	// Returns Run Time
	public long getRunTime() {
		return runTime;
	}
	
	// Returns Boolean Value Representing if Thread is Finished
	public boolean isFinished() {
		return isFinished;
	}
}
