<html>
	<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">   
   <title>Delete Student </title>
</head>
<body > 

<?php   			

require_once('Includes/DBQueries.php');		

// Check to see if Delete name is provided
if (isset($_GET["psusername"])) {
  $toDelete = $_GET["psusername"];
  // A bit dangerous without checks and use of getMethod
  deleteIt($toDelete);
  echo "$toDelete has been deleted from the Students Database.";   
  echo "<p></p>"; 
  echo "<a href='StudentApp.html'> Return to Student App.</a>";  
}
 else {
	    show_form();      	   
 }
  	
	
function show_form() { 			
	
	echo "<p></p>";
	echo "<h2> Select the Student to Delete</h2>";
	echo "<p></p>";	 	
	// Retrieve the students
	$students = selectStudents();
	
	echo "<h3> " . "Number of Students in Database is:  " . sizeof($students) . "</h3>";
	// Loop through table and display
	echo "<table border='1'>";
	foreach ($students as $data) {
	echo "<tr>";	
	// Provide Hyperlink for Selection
	// Could also use Form with Post method 
	echo "<td> <a href=DeleteStudent.php?psusername=" . $data->getPsusername() . ">" . "Delete" . "</a></td>";
	 echo "<td>" . $data->getFirstname() . "</td>";
	 echo "<td>" . $data->getLastname() . "</td>";
	 echo "<td>" . $data->getEmail() . "</td>";
	 echo "<td>" . $data->getPsusername() . "</td>";
	echo "</tr>";
}
	echo "</table>";

} // End Show form
?>

</body>
</html>
