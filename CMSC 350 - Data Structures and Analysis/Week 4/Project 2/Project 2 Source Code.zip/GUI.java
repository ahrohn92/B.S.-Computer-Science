import java.util.*;
import javax.swing.*;
import java.awt.event.*;
import java.io.IOException;

/*
 * Course:  	CMSC 350
 * File: 	GUI.java
 * Author: 	Andrew H. Rohn
 * Date: 	18 November 2018
 * Purpose: 	Contains Main Method that builds GUI
 */

public class GUI extends JFrame {
	
	// Variable Definition
	JLabel postfixLabel = new JLabel("Enter Postfix Expression");
	JLabel infixLabel = new JLabel("Infix Expression");
	JTextField postfixTextField = new JTextField("", 20);
	JTextField infixTextField = new JTextField("", 20);
	JButton button = new JButton("Construct Tree");

	public GUI () {
		
		// Creation of Postfix Panel
		JPanel postfixPanel = new JPanel();
		postfixPanel.add(postfixLabel);
		postfixPanel.add(postfixTextField);
		
		// Creation of Button Panel
		JPanel buttonPanel = new JPanel();
		buttonPanel.add(button);
		
		// Creation of Infix Panel
		JPanel infixPanel = new JPanel();
		infixPanel.add(infixLabel);
		infixPanel.add(infixTextField);
		infixTextField.setEditable(false);
		
		// Creation of Main Panel
		JPanel mainPanel = new JPanel();
		mainPanel.add(postfixPanel);
		mainPanel.add(buttonPanel);
		mainPanel.add(infixPanel);
		mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
		add(mainPanel);
		

	
	// Action Listener for Button
	button.addActionListener(new ActionListener() {
    	public void actionPerformed(ActionEvent e) {
    		
    		// Saving Input as String
    		String postfixExp = postfixTextField.getText();
    		
    		// Class Object
    		PostToInfix pti = new PostToInfix();
    		
    		// Checked Exception Methods
	  	    try {
	  	    	if (postfixExp.isEmpty()) {
	  	    		throw new NullPointerException();
		  	    } else {
		  	    	String InfixExp = (pti.postfixExpEval(postfixExp));
		  	    	infixTextField.setText(InfixExp);
		  	    }
	  	    } catch (NullPointerException nullPointer) {
	  	    	  JOptionPane.showMessageDialog(null, "Please enter a Postfix Expression.", "ERROR!",
	  	    			  JOptionPane.ERROR_MESSAGE);
	  	    } catch (EmptyStackException emptyStack) {
		  	      JOptionPane.showMessageDialog(null, "Invalid input.\nCheck for correct syntax of parentheses, operators, and operands.", "ERROR!",
		  	    		  JOptionPane.ERROR_MESSAGE);
	  	    } catch (InvalidInputException invalidInput) {
		  	      JOptionPane.showMessageDialog(null, "Invalid input.\nThe Postfix Expression can only contain "
		  	    		  + "integer operands (0-9)\n and the following arithmetic operators:\n +   -   *   /.", "ERROR!",
		  	    		  JOptionPane.ERROR_MESSAGE);
	  	    } catch (IOException ioException) {
	  	    		ioException.printStackTrace();
			}  		
        }
    });	
	}
	
	public static void main(String args[]) {
		
		GUI frame = new GUI();
		
		// Parameters for GUI frame
		frame.setTitle("Three Address Generator");
		frame.setSize(400, 145);
		frame.setLocationRelativeTo(null);
		frame.setResizable(false);
		frame.setVisible(true);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
}
