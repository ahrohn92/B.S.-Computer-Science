/* 
	Author: 	Andrew H. Rohn
	Date:		30 Nov 2018
	File:		SDEV300Lab6QSL.sql
	Course:		SDEV 300 - Section 7980
	Professor:	Mark Starcher
*/

use sdev300; 
 
/*
	TABLE CREATION
*/

-- Creation of Faculty Table (NumReq # 1)
CREATE TABLE Faculty ( 
	EMPLID varchar(10) primary key, 
	FirstName varchar(20), 
	LastName varchar(20), 
	EMail varchar(50),
	BirthYear int(4),
	HireDate varchar(30)
); 

-- Creation of Courses Table (NumReq # 2)
CREATE TABLE Courses ( 
	CourseID int(2) primary key, 
	DiscName varchar(4), 
	CourseNum int(3), 
	NumCredits int(1),
	InitOfferDate varchar (30),
	CourseTitle varchar(75) 
); 

-- Creation of FacultyCourses Table (NumReq # 3)
CREATE TABLE FacultyCourses ( 
	FacultyCourseID int(2) primary key, 
	CourseID int(2), 
	EMPLID varchar(10), 
	Constraint SC1 Foreign Key (CourseID) references Courses(CourseID) on delete cascade, 
	Constraint SC2 Foreign Key (EMPLID) references Faculty(EMPLID) On delete cascade 
);

/*
	TABLE POPULATION (NumReq # 4)
*/

-- Population of Faculty Table
insert into Faculty  
values ('71959-4446','Amy','Henderson','amy.henderson@faculty.umuc.edu','1979','August 7, 2008');  
insert into Faculty  
values ('40794-1141','Jacob','Preston','jacob.preston@faculty.umuc.edu','1984','February 11, 2009');  
insert into Faculty  
values ('60958-7025','Gary','Olson','gary.olson@faculty.umuc.edu','1966','June 8, 1992');   
insert into Faculty  
values ('34702-1861','Robyn','Phelps','robyn.phelps@faculty.umuc.edu','1982','September 22, 1997');  
insert into Faculty  
values ('80653-5740','Alaina','McKenna','alaina.mckenna@faculty.umuc.edu','1969','August 29, 1991');  
insert into Faculty  
values ('91283-9792','Sean','Douglas','sean.douglas@faculty.umuc.edu','1983','December 21, 2010'); 
insert into Faculty  
values ('86863-4120','Carol','Valentine','carol.valentine@faculty.umuc.edu','1970','June 21, 1996'); 
insert into Faculty  
values ('13563-1879','Howard','Calderon','howard.calderon@faculty.umuc.edu','1986','May 3, 2015');
insert into Faculty  
values ('76483-1796','Derrick','Whitmore','derrick.whitmore@faculty.umuc.edu','1991','May 10, 2018');  
insert into Faculty  
values ('60379-0774','Mariella','Gomez','mariella.gomez@faculty.umuc.edu','1988','July 15, 2017');
insert into Faculty  
values ('60561-2050','Caitlan','Dickens','caitlan.dickens@faculty.umuc.edu','1965','July 31, 1990');
insert into Faculty  
values ('15242-3312','Monica','Stewart','monica.stewart@faculty.umuc.edu','1967','March 16, 1994');
insert into Faculty  
values ('81168-2158','Thomas','Fuller','thomas.fuller@faculty.umuc.edu','1964','May 4, 1989');
insert into Faculty  
values ('35626-5723','Tyrique','Middleton','tyrique.middleton@faculty.umuc.edu','1992','November 9, 2015');
insert into Faculty  
values ('05354-6643','Yasser','Singh','yasser.singh@faculty.umuc.edu','1988','August 18, 2012');
insert into Faculty  
values ('34832-9045','Ricardo','Ramirez','ricardo.ramirez@faculty.umuc.edu','1994','January 24, 2017');
insert into Faculty  
values ('40866-0448','Charlie','Thorne','charlie.thorne@faculty.umuc.edu','1972','April 17, 2003');
insert into Faculty  
values ('73946-7801','Lucas','Easton','lucas.easton@faculty.umuc.edu','1975','August 2, 1999');
insert into Faculty  
values ('75819-8579','Juliet','Saunders','juliet.saunders@faculty.umuc.edu','1981','July 28, 2010');
insert into Faculty  
values ('23303-1758','Stacie','Wolf','stacie.wolf@faculty.umuc.edu','1978','February 8, 2006');

-- Population of Courses Table 
insert into Courses  
values (1, 'CMIS','102','3','August 7, 1998','Introduction to Problem Solving and Algorithm Design');
insert into Courses  
values (2, 'CMSC','150','3','August 9, 1998','Introduction to Discrete Structures');
insert into Courses  
values (3, 'CMIS','141','3','August 12, 1998','Introductory Programming');
insert into Courses  
values (4, 'CMIS','242','3','September 22, 2001','Intermediate Programming');
insert into Courses  
values (5, 'CMIS','310','3','September 26, 2001','Computer Systems and Architecture');
insert into Courses  
values (6, 'CMSC','330','3','July 3, 2002','Advanced Programming Languages');
insert into Courses  
values (7, 'CMSC','335','3','July 14, 2002','Object-Oriented and Concurrent Programming');
insert into Courses  
values (8, 'CMSC','350','3','July 15, 2002','Data Structures and Analysis');
insert into Courses  
values (9, 'CMIS','320','3','October 31, 2004','Relational Database Concepts and Applications');
insert into Courses  
values (10, 'SDEV','350','3','November 15, 2004','Database Security');
insert into Courses  
values (11, 'CMIS','330','3','February 4, 2005','Software Engineering Principles and Techniques');
insert into Courses  
values (12, 'SDEV','360','3','February 23, 2005','Secure Software Engineering');
insert into Courses  
values (13, 'CMIS','420','3','March 10, 2005','Advanced Relational Database Concepts and Applications');
insert into Courses  
values (14, 'CMIS','440','3','July 7, 2006','Advanced Programming in Java');
insert into Courses  
values (15, 'CMSC','405','3','November 3, 2009','Computer Graphics');
insert into Courses  
values (16, 'CMSC','412','3','January 24, 2010','Operating Systems');
insert into Courses  
values (17, 'CMSC','430','3','April 2, 2012','Compiler Theory and Design');
insert into Courses  
values (18, 'CMSC','451','3','March 29, 2014','Design and Analysis of Computer Algorithms');
insert into Courses  
values (19, 'SDEV','425','3','June 6, 2014','Mitigating Software Vulnerabilities');
insert into Courses  
values (20, 'SDEV','460','3','September 15, 2015','Software Security Testing');
 
-- Population of FacultyCourses Table
insert into FacultyCourses 
values (1,1,'71959-4446'); 
insert into FacultyCourses 
values (2,2,'40794-1141'); 
insert into FacultyCourses 
values (3,3,'60958-7025'); 
insert into FacultyCourses 
values (4,3,'05354-6643'); 
insert into FacultyCourses 
values (5,4,'34702-1861'); 
insert into FacultyCourses 
values (6,5,'80653-5740'); 
insert into FacultyCourses 
values (7,6,'91283-9792'); 
insert into FacultyCourses 
values (8,7,'86863-4120'); 
insert into FacultyCourses 
values (9,8,'13563-1879'); 
insert into FacultyCourses 
values (10,8,'05354-6643'); 
insert into FacultyCourses 
values (11,9,'76483-1796'); 
insert into FacultyCourses 
values (12,10,'60379-0774'); 
insert into FacultyCourses 
values (13,11,'60561-2050'); 
insert into FacultyCourses 
values (14,12,'15242-3312'); 
insert into FacultyCourses 
values (15,13,'81168-2158'); 
insert into FacultyCourses 
values (16,14,'35626-5723'); 
insert into FacultyCourses 
values (17,14,'40794-1141'); 
insert into FacultyCourses 
values (18,15,'05354-6643'); 
insert into FacultyCourses 
values (19,16,'34832-9045'); 
insert into FacultyCourses 
values (20,17,'40866-0448'); 
insert into FacultyCourses 
values (21,18,'73946-7801'); 
insert into FacultyCourses 
values (22,18,'81168-2158'); 
insert into FacultyCourses 
values (23,19,'75819-8579'); 
insert into FacultyCourses 
values (24,19,'91283-9792'); 
insert into FacultyCourses 
values (25,20,'23303-1758'); 

/*
	SQL MODIFYING STATEMENTS
*/

-- Updates all Courses to 6 credits (NumReq # 5)
update Courses 
set NumCredits = 6; 

-- Updates any Faculty with a birth year of 1994 and changes it to 1993 (NumReq # 6)
update Faculty 
set BirthYear = 1993 
where BirthYear = 1994; 
 
-- Deletes any Faculty record whose last name starts with the letters 'R' or 'S' (NumReq # 7)
delete from Faculty  
where LastName LIKE 'R%' OR LastName LIKE 'S%';

-- Deletes any Course record that was first offered in 2004 (NumReq # 8)
delete from Courses
where InitOfferDate LIKE '%2004';

/*
	SQL SELECTION STATEMENTS
*/

-- Displays all records in all 3 tables (NumReq # 9)
-- Displays Faculty query in descending order by last name
select * from Faculty
order by LastName DESC;

-- Displays Course query in ascending order by course title
select * from Courses
order by CourseTitle ASC;

-- Displays FacultyCourses query in no specific order
select * from FacultyCourses;

-- Displays all Faculty who have not taught at least 3 courses (NumReq # 10)
select A.EMPLID, FirstName, LastName, Email, BirthYear, HireDate 
from Faculty A, FacultyCourses B
where A.EMPLID = B.EMPLID
group by B.EMPLID
having count(CourseID) < 3;

-- Displays all Courses offered before 1999 (NumReq # 11)
select * from Courses
where RIGHT(InitOfferDate, 4) < '1999';

-- Displays all columns from the Faculty and Courses tables for each Faculty 
-- and Course in the FacultyCourse table (NumReq # 12)
select C.EMPLID, FirstName, LastName, Email, BirthYear, HireDate,
C.CourseID, DiscName, CourseNum, NumCredits, InitOfferDate, CourseTitle
from Faculty A, Courses B, FacultyCourses C
where C.EMPLID = A.EMPLID and C.CourseID = B.CourseID
order by C.CourseID ASC;