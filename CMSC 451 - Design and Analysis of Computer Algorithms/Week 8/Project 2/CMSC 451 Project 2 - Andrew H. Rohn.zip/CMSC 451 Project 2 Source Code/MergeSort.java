/*
 * Course:  	CMSC 451
 * File: 		MergeSort.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 April 2019
 * Purpose: 	Contains both the iterative and recursive Merge Sort functions. It increments both
 * 				critical operation count and execution time, which are used for analysis.
 */

public class MergeSort implements SortInterface {
	
	// Instance Variables
    int count = 0;
    long startTime = 0;
    long endTime = 0;
    
    // Iterative Merge Sort Function
    public int[] iterativeSort(int[] dataSet) throws UnsortedException {
        count++;
        startTime = System.nanoTime();
        int[] sortedDataSet = new int[dataSet.length];
        for (int subSetSize = 1; subSetSize < dataSet.length; subSetSize *= 2) {
            count++;
            for (int start = 0; start < dataSet.length; start += 2 * subSetSize) {
                merge(dataSet, sortedDataSet, start, start + subSetSize, start + 2 * subSetSize);
            }
        }
        endTime = System.nanoTime();
        return sortedDataSet;
    }
  
    // Recursive Merge Sort Function
    private void recursiveSort(int[] dataSet, int[] sortedDataSet, int low, int high) {
        count++;
        // Base Case
        if (high - low <= 1) {
            count++;
            return;
        }
        
        // Divide Set in Half and Sort Halves Recursively
        int middle = low + (high - low) / 2;
        recursiveSort(dataSet, sortedDataSet, low, middle);
        recursiveSort(dataSet, sortedDataSet, middle, high);
        
        // Merge Sub Sets Back Together
        merge(dataSet, sortedDataSet, low, middle, high);
    }
    
    // Initial Recursive Merge Sort Function
    public int[] recursiveSort(int[] dataSet) throws UnsortedException {
        count++;
        startTime = System.nanoTime();
        int[] sortedDataSet = new int[dataSet.length];
        recursiveSort(dataSet, sortedDataSet, 0, dataSet.length);
        endTime = System.nanoTime();
        return sortedDataSet;
    }
    
    // Merges Sub Sets Back Together 
    private void merge(int[] dataSet, int[] sortedDataSet, int low, int middle, int high) {
        count++;
        if (middle >= dataSet.length) {
            count++;
            return;
        }
        if (high > dataSet.length) {
            count++;
            high = dataSet.length;
        }
        int i = low, j = middle;
        for (int k = low; k < high; k++) {
            count++;
            if (i == middle) {
                count++;
                sortedDataSet[k] = dataSet[j++];
            } else if (j == high) {
                count++;
                sortedDataSet[k] = dataSet[i++];
            } else if (dataSet[j] < dataSet[i]) {
                count++;
                sortedDataSet[k] = dataSet[j++];
            } else {
                count++;
                sortedDataSet[k] = dataSet[i++];
            }
        }
        for (int k = low; k < high; k++) {
            count++;
            dataSet[k] = sortedDataSet[k];
        }
    }
    
    // Getter Method for Count
    public int getCount() {
    	int count = this.count;
    	this.count = 0;
        return count;
    }
    
    // Getter Method for Time
    public long getTime() {
        long time = endTime - startTime;
        startTime = 0;
        endTime = 0;
        return time;
    }
}