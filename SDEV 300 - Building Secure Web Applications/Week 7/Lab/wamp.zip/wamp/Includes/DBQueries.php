<?php  

function selectStudents ()
  {
		require_once('Includes/DBConnect.php');		
		require_once('Includes/DBClasses.php');		
		// Connect to the database
   $mysqli = connectdb();
		
	 
		// Add Prepared Statement
		$Query = "Select firstName,lastName,eMail,Psusername from Students";	         
	          
		$result = $mysqli->query($Query);
		$myStudents = array();
if ($result->num_rows > 0) {    
    while($row = $result->fetch_assoc()) {
    	// Assign values
    	$firstname = $row["firstName"];
    	$lastname = $row["lastName"];
    	$email = $row["eMail"];
    	$psusername= $row["Psusername"];    	
      
       // Create a Student instance     
       $studentData = new Studentclass($firstname,$lastname,$email,$psusername);
       $myStudents[] = $studentData;         
      }    
 } 

	$mysqli->close();
	
	return $myStudents;		
		
	}
	  	
	  	
?>