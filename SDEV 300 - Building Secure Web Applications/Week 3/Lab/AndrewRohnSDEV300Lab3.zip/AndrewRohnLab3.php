<!-- SDEV 300 Lab 3
Date: Nov 11, 2018
Author: Andrew H. Rohn
Title: AndrewRohnLab3.php
Description: Uses HTML and PHP to create two tables. One for mathematical functions 
			 and the other for modifying a quote.
-->

<!DOCTYPE html>
<html>
<head>
	<title>PHP Mathematical Functions & Famous Quote Tables</title>
</head>
<body>
	<h1>Table 1: PHP Mathematical Functions</h1>
	<table border="1">
	<tr>
		<th>Mathematical Functions w/ Constant Values </th>
		<th colspan="420">Variables</th>
	</tr>
	<tr>
		<td rowspan="2">Slope Intercept (y)</br></br>
			Equation:</br>y = mx + b</br></br>
			Given: m = -2 & b = 0
		</td>
		<td colspan="105">x = 2</td>
		<td colspan="105">x = 5</td>
		<td colspan="105">x = 8</td>
		<td colspan="105">x = 10</td>
	</tr>
		<?php
			// Funtion for Slope Intercept
			function slopeInt($val) {
				return -2 * $val + 0;
			}
			// X-Int Array
			$xInt = array(2,5,8,10);
			// Nested Loop for Y-intercept Values
			for ($count = 0; $count < 4; $count++) {
		?>
			<td colspan="105"><?php echo "y = ".slopeInt($xInt[$count])."";?></td>
		<?php
		}
		?>
	<tr>
	</tr>
	<tr>
		<td rowspan="2">Surface Area of a Sphere (A)</br></br>
			Equation:</br>A = 4&#960R<sup>2</sup>
		</td>
		<td colspan="84">R = 2</td>
		<td colspan="84">R = 6</td>
		<td colspan="84">R = 10</td>
		<td colspan="84">R = 100</td>
		<td colspan="84">R = 1000</td>
	</tr>
	<tr>
		<?php
			// Funtion for Surface Area of Sphere
			const PI = 3.14159265359;
			function surfaceAreaSphere($val) {
				return 4 * PI * $val * $val;
			}
			// Radius Array
			$radius = array(2,6,10,100,1000);
			// Nested Loop for Surface Area Values
			for ($count = 0; $count < 5; $count++) {
		?>
			<td colspan="84"><?php echo "A = ".round(surfaceAreaSphere($radius[$count]), 2)."";?></td>
		<?php
		}
		?>
	</tr>
	<tr>
		<td rowspan="3">Distance Object Travels (d)</br></br>
			Equation:</br>d = vt
		</td>
		<td colspan="105">v = 10m/s</td>
		<td colspan="105">v = 30m/s</td>
		<td colspan="105">v = 327m/s</td>
		<td colspan="105">v = 1200m/s</td>
	</tr>
	<tr>
		<?php
			// Nested Loop for Time Intervals
			for ($i = 0; $i < 4; $i++) {
		?>
			<?php
				$t = 0.0;
				for($j = 0; $j < 21; $j++) {
			?>
				<td colspan="5"><?php echo "t = ".$t."s";?></td>
			<?php
				$t += 0.5;
			}
			?>
		<?php
		}
		?>
	</tr>
	<tr>
		<?php
			// Function for Distance Traveled
			function distance($speed, $time) {
				return $speed * $time;
			}
			// Speed Array
			$speeds = array(10,30,327,1200);
			// Nested Loop for Distance Traveled
			for ($i = 0; $i < 4; $i++) {
		?>
			<?php
				$time = 0.0;
				for($j = 0; $j < 21; $j++) {
			?>
				<td colspan="5"><?php echo "d = ".distance($speeds[$i], $time)."m";?></td>
			<?php
				$time += 0.5;
			}
			?>
		<?php
		}
		?>
	</tr>
	</table>
	</br></br>
	
	<h2>Table 2: Modification of a Famous Quote with PHP String Functions</h2>
	<table border="1">
	
		<!-- Headers -->
		<th>
			PHP String Functions
		</th>
		<th>
			Modified Quote
		</th>
		
		<!-- Famous Quote -->
		<?php
		$quote = "Shall we expect some transatlantic military giant to step the ocean and 
			crush us at a blow? Never! All the armies of Europe, Asia, and Africa combined, 
			with all the treasure of the earth (our own excepted) in their military chest, 
			with a Bonaparte for a commander, could not by force take a drink from the Ohio 
			or make a track on the Blue Ridge in a trial of a thousand years. At what point 
			then is the approach of danger to be expected? I answer. If it ever reach us it 
			must spring up amongst us; it cannot come from abroad. If destruction be our lot 
			we must ourselves be its author and finisher. As a nation of freemen we must live 
			through all time or die by suicide."
		?>
	<tr>
		<td>
			Original Quote
		</td>
		<td>
			<?php echo $quote; ?> </br></br>
			- President Abraham Lincoln
		</td>
	</tr>
	<tr>
		<td>
			The First Letter of Each Word is Capitalized</br></br>
			PHP Function:</br>ucwords()
		</td>
		<td>
			<?php echo ucwords($quote); ?>
		</td>
	</tr>
	<tr>
		<td>
			The Length of Each Word in the Quote is Displayed and Seperated by Commas</br></br>
			PHP Functions:</br>str_word_count()</br>preg_split()</br>strlen()</br>
		</td>
		<td>
			<?php			
				// Counts Number of Words in String
				$wordCount = str_word_count($quote);
				// Splits String into Seperate Words
				$splitWords = preg_split("/[^\w]*([\s]+[^\w]*|$)/", $quote, -1, PREG_SPLIT_NO_EMPTY);
				// Prints Word Length
				for ($i = 0; $i < $wordCount; $i++) {
					if ($i == $wordCount - 1) {
						echo strlen($splitWords[$i]);
					} else {
						echo "".strlen($splitWords[$i]).", ";
					}		
				}	
			?>
		</td>
	</tr>
	<tr>
		<td>
			Each Word in the Quote is Shuffled</br></br>
			PHP Function:</br>str_word_count()</br>preg_split()</br>str_shuffle()</br>
		</td>
		<td>
			<?php
				// Shuffles Words
				for ($i = 0; $i < $wordCount; $i++) {
					if ($i == $wordCount - 1) {
						echo "".str_shuffle($splitWords[$i]).".";
					} else {
						echo "".str_shuffle($splitWords[$i])." ";
					}	
				}	
			?>
		</td>
	</tr>
</body>
</html>
	