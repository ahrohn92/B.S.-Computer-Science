<?php
// Connects to Wamp Database
include_once 'Includes/connectDB.php';

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}

$userName = mysqli_real_escape_string($conn, $userName);
$passWord = mysqli_real_escape_string($conn, $passWord);

// Checks if Username and Password are Original
$sql_5 = "SELECT * FROM players WHERE Username='$userName';";
$sql_6 = "SELECT * FROM players WHERE Password='$passWord';";

if (mysqli_num_rows(mysqli_query($conn, $sql_5)) == 0) {
	$userCheck = false;
} else {
	$userCheck = true;
}	

if (mysqli_num_rows(mysqli_query($conn, $sql_6)) == 0) {
	$passCheck = false;
} else {
	$passCheck = true;
}

// Checks for errors
if(mysqli_query($conn, $sql_5)){
	echo "";
} else{
	echo mysqli_error($conn);
}

if(mysqli_query($conn, $sql_6)){
	echo "";
} else{
	echo mysqli_error($conn);
}

// Closes Connection to Database
mysqli_close($conn);

?>