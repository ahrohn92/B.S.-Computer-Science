import java.util.Arrays;
import java.util.InputMismatchException;
import java.util.Random;
import java.util.Scanner;
import java.util.Stack;

/*
 * Course:		CMSC 412
 * File:		DemandPagingSimulator.java
 * Author:		Andrew H. Rohn
 * Date:		11 Oct 2019
 * Purpose:		This program generates a text menu with options for the user to end
 * 				the program, enter a reference string, generate a random reference
 * 				string, view the currently stored reference string, and use the stored
 * 				reference string to simulate the FIFO, OPT, LRU, and LFU demand
 * 				paging algorithms.
 */

public class DemandPagingSimulator {

	// Global Variables
	private static Integer userInput = null;
	private static boolean userInputIsValid = false;
	private static boolean createNewMenu = true;
	private static int numFrames;
	private static int numPageFaults;
	private static Scanner input;
	private static StringBuffer referenceString;
	
	// Main Method
	public static void main(String args[]) {
		
		boolean argsIsValid = false;
		
		// Checks if Argument is Present/Valid
		if (args.length != 0) {
			input = new Scanner(System.in);
			try {
				numFrames = Integer.parseInt(args[0]);
				if (numFrames > 0 && numFrames < 8) {
					argsIsValid = true;
				} else {
					System.out.println("ERROR: Argument is not valid");
				}
			} catch (InputMismatchException ime) {
				System.out.println("ERROR: Argument is not valid");
			} catch (NumberFormatException nfe) {
				System.out.println("ERROR: Argument is not valid");
			}
		}
		if (!argsIsValid) {
			System.out.print("Enter number of frames: ");
			while (!userInputIsValid) {
				input = new Scanner(System.in);
				try {
					numFrames = input.nextInt();
					if (numFrames > 0 && numFrames < 8) {
						userInputIsValid = true;
					} else {
						System.out.print("Please enter an integer between 1 and 7: ");
					}
				} catch (InputMismatchException ime) {
					System.out.print("Please enter an integer between 1 and 7: ");
				}
			}
		}

		// Checks if User Input is Valid
		userInputIsValid = false;
		while (!userInputIsValid) {
			
			// Creates Text Menu
			if (createNewMenu) {
				createMenu();
				createNewMenu = false;
			}
			
			// Loop That Handles User Input
			input = new Scanner(System.in);
			try {
				userInput = input.nextInt();
				if (userInput >= 0 && userInput <= 7) {
					userInputIsValid = true;
					processUserInput(userInput);
				} else {
					userInputIsValid = false;
					System.out.print("Please enter an integer between 0 and 7: ");
				}
			} catch (InputMismatchException ime) {
				userInputIsValid = false;
				System.out.print("Please enter an integer between 0 and 7: ");
			}
		}
		input.close();
	}
	
	// Prints Text Menu to Console
	private static void createMenu() {
		System.out.println("\n-------------- USER OPTIONS --------------\n");
		System.out.println("Number of Frames: "+numFrames);
		System.out.println("\n0 - Exit");
		System.out.println("1 - Read reference string");
		System.out.println("2 - Generate reference string");
		System.out.println("3 - Display current reference string");
		System.out.println("4 - Simulate FIFO");
		System.out.println("5 - Simulate OPT");
		System.out.println("6 - Simulate LRU");
		System.out.println("7 - Simulate LFU");
		System.out.print("\nSelect option: ");
	}
	
	// Determines Program Function Based on User Input
	private static void processUserInput(int userInput) {
		char[][] pageFrame;
		switch (userInput) {
			case 0:	
				System.out.println("Program Ended");
				System.exit(0); // Exits Program
				break;
			case 1: 
				System.out.println("Option Selected: 1 - Read reference string");
				referenceString = readReferenceString();
				break;
			case 2:
				System.out.println("Option Selected: 2 - Generate reference string");
				referenceString = generateReferenceString();
				break;
			case 3:
				System.out.println("Option Selected: 3 - Display current reference string");
				if (referenceString != null) {
					System.out.println("\nCurrent Reference String: "+referenceString);
				} else {
					System.out.println("\nERROR: There is no reference string stored");
				}
				break;
			case 4:
				System.out.println("Option Selected: 4 - Simulate FIFO");
				if (referenceString != null) {
					pageFrame = FIFO_Algorithm(referenceString);
					displaySimulation("FIFO", pageFrame);
				} else {
					System.out.println("\nERROR: There is no reference string stored");
				}
				break;
			case 5:
				System.out.println("Option Selected: 5 - Simulate OPT");
				if (referenceString != null) {
					pageFrame = OPT_Algorithm(referenceString);
					displaySimulation("OPT", pageFrame);
				} else {
					System.out.println("\nERROR: There is no reference string stored");
				}
				break;
			case 6:
				System.out.println("Option Selected: 6 - Simulate LRU");
				if (referenceString != null) {
					pageFrame = LRU_Algorithm(referenceString);
					displaySimulation("LRU", pageFrame);
				} else {
					System.out.println("\nERROR: There is no reference string stored");
				}
				break;
			case 7:
				System.out.println("Option Selected: 7 - Simulate LFU");
				if (referenceString != null) {
					pageFrame = LFU_Algorithm(referenceString);
					displaySimulation("LFU", pageFrame);
				} else {
					System.out.println("\nERROR: There is no reference string stored");
				}
				break;
			default: System.out.print("Please enter an integer between 0 and 7: ");
				break;
		}
		userInputIsValid = false;
		createNewMenu = true;
	}
	
	// Reads Reference String from Keyboard
	private static StringBuffer readReferenceString() {
		
		StringBuffer referenceString = new StringBuffer();
		int referenceStringLength = 0;
		boolean lengthIsValid = false;
		
		while (!lengthIsValid) {
			System.out.print("\nEnter the length of the reference string (max 25): ");
			try {
				input = new Scanner(System.in);
				referenceStringLength = input.nextInt();
				if (referenceStringLength > 0 && referenceStringLength <= 25) {
					lengthIsValid = true;
				} else {
					System.out.println("ERROR: Reference string length must be an integer between 1 and 25");
				}
			} catch (InputMismatchException ime) {
				System.out.println("ERROR: Reference string length must be an integer between 1 and 25");
			}
		}
		for (int i = 0; i < referenceStringLength; i++) {
			System.out.print("\nEnter page #: ");
			input = new Scanner(System.in);
			try {
				int pageNumber = input.nextInt();
				if (pageNumber >= 0 && pageNumber <= 9) {
					if (i == referenceStringLength-1) {
						referenceString.append(pageNumber);
					} else {
						referenceString.append(pageNumber+" ");
					}
				} else {
					System.out.println("ERROR: Page number must be an integer between 0 and 9");
					i--;
				}
			} catch (InputMismatchException ime) {
				System.out.println("ERROR: Page number must be an integer between 0 and 9");
				i--;
			}
		}
		return referenceString;
	}
	
	// Generates a Random Reference String
	private static StringBuffer generateReferenceString() {
		
		Random rand = new Random();
		StringBuffer referenceString = new StringBuffer();
		int referenceStringLength = 0;
		boolean lengthIsValid = false;
		
		while (!lengthIsValid) {
			System.out.print("\nEnter the length of the reference string (max 25): ");
			try {
				input = new Scanner(System.in);
				referenceStringLength = input.nextInt();
				if (referenceStringLength > 0 && referenceStringLength <= 25) {
					lengthIsValid = true;
				} else {
					System.out.println("ERROR: Reference string length must be an integer between 1 and 25");
				}
			} catch (InputMismatchException ime) {
				System.out.println("ERROR: Reference string length must be an integer between 1 and 25");
			}
		}
		for (int i = 0; i < referenceStringLength; i++) {
			if (i == referenceStringLength-1) {
				referenceString.append(rand.nextInt((9 - 0) + 1));
			} else {
				referenceString.append(rand.nextInt((9 - 0) + 1)+" ");
			}
		}
		return referenceString;
	}
	
	// Displays Algorithm Solution Step by Step
	private static void displaySimulation(String algorithm, char[][] pageFrame) {

		String[] lines;
		int step = 1;
		
		while (step <= pageFrame.length) {
			input.nextLine();
			clearConsole();
			lines = new String[numFrames+2];
			Arrays.fill(lines, "");
			
			// Divides Completed Page Frame Into Lines
			for (int j = 0; j < step; j++) {
				for (int i = 0; i < pageFrame[j].length; i++) {
					lines[i] += " "+pageFrame[j][i];
				}
			}
			
			// Print Lines Together With Formatting
			System.out.println("\n"+algorithm+" Step # "+step+"\n");
			System.out.println("Reference String | "+referenceString);
			System.out.print("-------------------");
			for (int i = 0; i < referenceString.length(); i++) {
				System.out.print("-");
			}
			System.out.println();
			for (int i = 0; i < lines.length; i++) {
				if (i == lines.length-2) {
					System.out.print("-------------------");
					for (int j = 0; j < referenceString.length(); j++) {
						System.out.print("-");
					}
					System.out.println();
					System.out.println("Page Faults      |"+lines[i]);
				} else if (i == lines.length-1) {
					System.out.println("Victim Frames    |"+lines[i]);;
				} else {
					System.out.println("Physical Frame "+i+" |"+lines[i]);
				}
			}
			if (step != pageFrame.length) {
				System.out.println("\nPress ENTER to continue");
			} else {
				System.out.println("\n\nNumber of Page Faults: "+numPageFaults+"\n");
			}
			step++;
		}
	}
	
	// FIFO Algorithm
	private static char[][] FIFO_Algorithm(StringBuffer referenceString) {
		
		StringBuilder temp = new StringBuilder(referenceString.toString().replaceAll("\\s", ""));
		char[] RAM = new char[numFrames+2];
		char[][] pageFrame = new char[temp.length()][RAM.length];
		int[] durations = new int[numFrames];
		numPageFaults = 0;
		
		for (int j = 0; j < temp.length(); j++) {
			
			RAM = Arrays.copyOf(RAM, numFrames+2);
			durations = Arrays.copyOf(durations, numFrames);
			
			if (pageNeedsReplacement(RAM,temp,j)) {

				int longestDuration = 0;
				
				// Determines Page With Longest Duration
				for (int i = 0; i < durations.length; i++) {
					if (durations[i] > longestDuration) {
						longestDuration = durations[i];
					}
				}
				
				// Replaces Page With Longest Duration
				for (int i = 0; i < durations.length; i++) {
					if (durations[i] == longestDuration) {
						RAM[numFrames+1] = RAM[i];
						RAM[i] = temp.charAt(j);
						durations[i] = 0;
						RAM[numFrames] = 'F';
						numPageFaults++;
						break;
					}
				}
			}

			// Increments Non-Null Durations
			for (int i = 0; i < durations.length; i++) {
				if (RAM[i] != '\u0000') {
					durations[i]++;
				}
			}
			pageFrame[j] = RAM;
		}
		return pageFrame;
	}
	
	// OPT Algorithm
	private static char[][] OPT_Algorithm(StringBuffer referenceString) {
		
		StringBuilder temp = new StringBuilder(referenceString.toString().replaceAll("\\s", ""));
		char[] RAM = new char[numFrames+2];
		char[][] pageFrame = new char[temp.length()][RAM.length];
		numPageFaults = 0;
		
		for (int j = 0; j < temp.length(); j++) {
			
			RAM = Arrays.copyOf(RAM, numFrames+2);
			
			if (pageNeedsReplacement(RAM,temp,j)) {

				int[] distances = new int[numFrames];
				
				// Determines Distances of Pages in RAM
				for (int i = 0; i < numFrames; i++) {
					for (int nextIndex = j+1; nextIndex < temp.length(); nextIndex++) {
						if (RAM[i] == temp.charAt(nextIndex)) {
							distances[i] = nextIndex - j;
							break;
						}
					}
				}
				
				// Determines Which Distance is Farthest
				Integer victimFrame = null;
				int farthestDistance = 0;
				for (int i = 0; i < distances.length; i++) {
					if (distances[i] == 0) {
						victimFrame = i;
						break;
					}
					if (distances[i] > farthestDistance) {
						farthestDistance = distances[i];
					}
				}
				
				// Replaces Page With Farthest Distance
				if (victimFrame == null) {
					for (int i = 0; i < distances.length; i++) {
						if (distances[i] == farthestDistance) {
							victimFrame = i;
						}
					}
				}
				RAM[numFrames+1] = RAM[victimFrame];
				RAM[victimFrame] = temp.charAt(j);
				RAM[numFrames] = 'F';
				numPageFaults++;
			}
			pageFrame[j] = RAM;
		}
		return pageFrame;
	}
	
	// LRU Algorithm
	private static char[][] LRU_Algorithm(StringBuffer referenceString) {
		
		StringBuilder temp = new StringBuilder(referenceString.toString().replaceAll("\\s", ""));
		char[] RAM = new char[numFrames+2];
		char[][] pageFrame = new char[temp.length()][RAM.length];
		Stack<Character> stack = new Stack<Character>();
		numPageFaults = 0;
		
		for (int j = 0; j < temp.length(); j++) {
			
			RAM = Arrays.copyOf(RAM, numFrames+2);
			
			if (pageNeedsReplacement(RAM,temp,j)) {
				
				int leastRecent = 0;
				
				// Determines Which Page is the Least Recently Used
				for (int i = 0; i < numFrames; i++) {
					if (stack.search(RAM[i]) > leastRecent) {
						leastRecent = stack.search(RAM[i]);
					}
				}
				
				// Replaces Least Recently Used Page
				for (int i = 0; i < numFrames; i++) {
					if (RAM[i] == stack.get(stack.size()-leastRecent)) {
						RAM[numFrames+1] = RAM[i];
						RAM[i] = temp.charAt(j);
						RAM[numFrames] = 'F';
						numPageFaults++;
						break;
					}
				}
			}
			stack.push(temp.charAt(j));
			pageFrame[j] = RAM;
		}
		return pageFrame;
	}
	
	// LFU Algorithm
	private static char[][] LFU_Algorithm(StringBuffer referenceString) {
		
		StringBuilder temp = new StringBuilder(referenceString.toString().replaceAll("\\s", ""));
		char[] RAM = new char[numFrames+2];
		char[][] pageFrame = new char[temp.length()][RAM.length];
		int[] uses = new int[10];
		int[] durations = new int[numFrames];
		numPageFaults = 0;
		
		for (int j = 0; j < temp.length(); j++) {
			
			RAM = Arrays.copyOf(RAM, numFrames+2);
			durations = Arrays.copyOf(durations, numFrames);
			uses = Arrays.copyOf(uses, 10);
			
			if (pageNeedsReplacement(RAM,temp,j)) {
				
				int longestDuration = 0;
				
				// Determines Page With Longest Duration
				for (int i = 0; i < durations.length; i++) {
					if (durations[i] > longestDuration) {
						longestDuration = durations[i];
					}
				}
				
				Integer leastUsed = null;
				
				// Determines Least Frequently Used Page
				for (int i = 0; i < numFrames; i++) {
					if (leastUsed == null || uses[Character.getNumericValue(RAM[i])] < leastUsed) {
						leastUsed = uses[Character.getNumericValue(RAM[i])];
					}
				}
				
				// Determines if Multiple Pages Have the Same Least Used Value
				int numPagesWithLeastUsed = 0;
				for (int i = 0; i < numFrames; i++) {
					if (uses[Character.getNumericValue(RAM[i])] == leastUsed) {
						numPagesWithLeastUsed++;
					}
				}

				// If Multiple Pages Have Same Least Used Value, FIFO is Applied
				if (numPagesWithLeastUsed > 1) {
					longestDuration = 0;
					for (int i = 0; i < durations.length; i++) {
						if (uses[Character.getNumericValue(RAM[i])] == leastUsed) {
							if (durations[i] > longestDuration) {
								longestDuration = durations[i];
							}	
						}	
					}
					// Replaces Page With Longest Duration
					for (int i = 0; i < numFrames; i++) {
						if (durations[i] == longestDuration) {
							uses[Character.getNumericValue(RAM[i])] = 0;
							RAM[numFrames+1] = RAM[i];
							RAM[i] = temp.charAt(j);
							durations[i] = 0;
							RAM[numFrames] = 'F';
							numPageFaults++;
							break;
						}
					}		
				} else {
					// Otherwise Least Used Page is Replaced
					for (int i = 0; i < numFrames; i++) {
						if (uses[Character.getNumericValue(RAM[i])] == leastUsed) {
							uses[Character.getNumericValue(RAM[i])] = 0;
							RAM[numFrames+1] = RAM[i];
							RAM[i] = temp.charAt(j);
							durations[i] = 0;
							RAM[numFrames] = 'F';
							numPageFaults++;
							break;
						}
					}
				}
			}
			uses[Character.getNumericValue(temp.charAt(j))]++;
			
			// Increments Non-Null Durations
			for (int i = 0; i < durations.length; i++) {
				if (RAM[i] != '\u0000') {
					durations[i]++;
				}
			}
			pageFrame[j] = RAM;
		}
		return pageFrame;
	}
	
	// Determines if a Page in RAM Needs to be Replaced
	private static boolean pageNeedsReplacement(char[] RAM, StringBuilder temp, int j) {
		
		boolean needsReplacement = true;
		
		for (int i = 0; i < numFrames; i++) {
			
			// Checks for Empty Slot
			if (RAM[i] == '\u0000') {
				RAM[i] = temp.charAt(j);
				RAM[numFrames] = 'F';
				needsReplacement = false;
				numPageFaults++;
				break;
			}
			
			// Checks for Presence of Page
			if (RAM[i] == temp.charAt(j)) {
				RAM[numFrames] = ' ';
				RAM[numFrames+1] = ' ';
				needsReplacement = false;
				break;
			}
		}
		return needsReplacement;
	}
	
	// Clears Console in Windows CMD
	private static void clearConsole() {
		try {
			new ProcessBuilder("cmd","/c","cls").inheritIO().start().waitFor();
		} catch (Exception e) {
			System.out.println();
		}
	}
}