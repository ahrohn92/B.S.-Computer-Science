/*
 * Course:  	CMSC 350
 * File: 		CycleDetectedException.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 December 2018
 * Purpose: 	Contains CycleDetectedException constructor.
 */

public class CycleDetectedException extends Exception {

	CycleDetectedException() {}

}