import java.awt.*;
import javax.swing.*;
import javax.swing.table.*;
import java.text.DecimalFormat;

/*
 * Course:  	CMSC 451
 * File: 		SortMain.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 April 2019
 * Purpose: 	Contains Main Method that constructs JTable. It also passes the data set sizes to the BenchmarkSorts Class.
 */

public class SortMain extends JFrame {
	
	// Local Variables
	static int[] dataSetSizes = {100, 200, 300, 400, 500, 600, 700, 800, 900, 1000};
	String[] tableHeaders = {"<html><br><br>Data Set<br>Size n<br><br></html>", "<html>Iterative<br>Average<br>Critical<br>Operation<br>Count</html>",
			"<html>Iterative<br>Coefficient of<br>Variance of<br>Count</html>", "<html>Iterative<br>Average<br>Execution<br>Time</html>",
			"<html>Iterative<br>Coefficient of<br>Variance of<br>Time</html>", "<html>Recursive<br>Average<br>Critical<br>Operation<br>Count</html>",
			"<html>Recursive<br>Coefficient of<br>Variance of<br>Count</html>", "<html>Recursive<br>Average<br>Execution<br>Time</html>",
			"<html>Recursive<br>Coefficient of<br>Variance of<br>Time</html>"};
	Object[][] tableData = new Object[dataSetSizes.length][tableHeaders.length];
	
	// Constructor for GUI
	public SortMain() {
		
		// Population of Data Table with Data Sizes
		for (int i = 0; i < dataSetSizes.length; i++) {
			tableData[i][0] = "<html><b>"+dataSetSizes[i]+"</b></html>";
		}
        
        // Calls Main Sorting Function and Adds Results to JTable
		DecimalFormat df1 = new DecimalFormat("0.0");
		DecimalFormat df2 = new DecimalFormat("0.####");
        int i = 0, j = 1;
        for (double result : new BenchmarkSorts(dataSetSizes).getResults()) {
        	if (j == 3 || j == 7) {
        		tableData[i][j] = df1.format(result/1000)+" ms";
        	} else {
        		tableData[i][j] = df2.format(result);
        	}
        	j++;
        	if (j >= tableHeaders.length) {
        		j = 1;
        		i++;
        	}
        }
        
        // Creation of JTable
		DefaultTableModel tableModel = new DefaultTableModel(tableData, tableHeaders) {
			public boolean isCellEditable(int row, int column) {
				return false;
			}
		};
		JTable table = new JTable(tableModel);
		table.setFillsViewportHeight(true);
		JScrollPane scrollPane = new JScrollPane(table);
		add(scrollPane, BorderLayout.CENTER);
		
		// Customizes Table Headers
		JTableHeader headers = table.getTableHeader();
		((DefaultTableCellRenderer)headers.getDefaultRenderer()).setVerticalAlignment(JLabel.CENTER);
		headers.setBackground(Color.BLUE);
		headers.setForeground(Color.WHITE);	
	}
	
	// Main Method
    public static void main(String[] args) throws Exception {
    	
        SortMain main = new SortMain();
    	
        // GUI Parameters
        main.setVisible(true);
        main.setTitle("CMSC 451 Project 1");
        main.setSize(900,286);
        main.setLayout(new GridLayout(1,1));
        main.setResizable(false);
        main.setLocationRelativeTo(null);
        main.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    }
}