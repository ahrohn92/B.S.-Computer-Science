import java.awt.Color;
import java.util.ArrayList;

/*
 * Course:  	CMSC 405
 * File: 		Shapes.java
 * Author: 		Andrew H. Rohn
 * Date: 		29 June 2019
 * Purpose: 	This class creates six shapes that are called and rendered in the main class.
 */

public class Shapes {

	// Local Variables
	public ArrayList<double[][]> verticesList = new ArrayList<double[][]>();
	public ArrayList<int[][]> facesList = new ArrayList<int[][]>();
	public ArrayList<Color> colorList = new ArrayList<Color>();
	private double[][] vertices;
	private int[][] faces;
	private Color color;
	
	// Constructor
	public Shapes() {

		// Triangular Prism
		vertices = new double[][]{
	        {1,0.5,0},
	        {1,-0.5,0.5},
	        {1,-0.5,-0.5},
	        {-1,0.5,0},
	        {-1,-0.5,0.5},
	        {-1,-0.5,-0.5}
		};
		faces = new int[][] {
            {0,2,1},
            {0,1,4,3},
            {0,3,5,2},
            {2,1,4,5},
            {3,5,4}
		}; 
		color = Color.GREEN;
		verticesList.add(vertices);
		facesList.add(faces);
		colorList.add(color);
		
		// Cube
		vertices = new double[][] {
            {-0.5,0.5,0.5},
            {-0.5,0.5,-0.5},
            {0.5,0.5,0.5},
            {0.5,0.5,-0.5},
            {-0.5,-0.5,0.5},
            {-0.5,-0.5,-0.5},
            {0.5,-0.5,0.5},
            {0.5,-0.5,-0.5}
        };
		faces = new int[][] {
     	   	{0,1,3,2},
     	   	{2,6,4,0},
     	   	{0,4,5,1},
     	   	{1,5,7,3},
     	   	{3,7,6,2},
     	   	{6,4,5,7}
        }; 
		color = Color.YELLOW;
		verticesList.add(vertices);
		facesList.add(faces);
		colorList.add(color);
		
		// Pyramid
		vertices = new double[][] {
			{0,0.75,0},
			{-0.75,-0.75,0.75},
			{-0.75,-0.75,-0.75},
			{0.75,-0.75,-0.75},
			{0.75,-0.75,0.75}
        };
        faces = new int[][] {
        	{0,4,1},
        	{0,1,2},
        	{0,2,3},
        	{0,3,4},
        	{1,2,3,4}
        };
        color = new Color(102,0,153); // PURPLE
		verticesList.add(vertices);
		facesList.add(faces);
		colorList.add(color);
		
		// Icosahedron
		vertices = new double[][] {
            {0,1,0},
            {0,0.5,1},
            {-0.951,0.5,0.309},
            {-0.588,0.5,-0.809},
            {0.588,0.5,-0.809},
            {0.951,0.5,0.309},
            {0,-0.5,-1},
            {0.951,-0.5,-0.309},
            {0.588,-0.5,0.809},
            {-0.588,-0.5,0.809},
            {-0.951,-0.5,-0.309},
            {0,-1,0}
		};
		faces = new int[][] {
			{0,1,2},
			{0,2,3},
			{0,3,4},
			{0,4,5},
			{0,5,1},
			{1,8,9},
			{1,9,2},
			{9,2,10},
			{2,10,3},
			{10,3,6},
			{3,6,4},
			{6,4,7},
			{4,7,5},
			{7,5,8},
			{5,8,1},
			{11,8,9},
			{11,9,10},
			{11,10,6},
			{11,6,7},
			{11,7,8}
        };
        color = Color.RED;
		verticesList.add(vertices);
		facesList.add(faces);
		colorList.add(color);
        
        // Diamond
        vertices = new double[][] {
            {-0.25,1,0.5},
            {0.25,1,0.5},
            {0.5,1,0},
            {0.25,1,-0.5},
            {-0.25,1,-0.5},
            {-0.5,1,0},
            {-0.429,0.5,1},
            {0.429,0.5,1},
            {1,0.5,0},
            {0.429,0.5,-1},
            {-0.429,0.5,-1},
            {-1,0.5,0},
            {0,-1,0}
        };
        faces = new int[][] {
            {0,1,2,3,4,5},
            {0,1,7,6},
            {1,2,8,7},
            {2,3,9,8},
            {3,4,10,9},
            {4,5,11,10},
            {5,0,6,11},
            {6,7,12},
            {7,8,12},
            {8,9,12},
            {9,10,12},
            {10,11,12},
            {11,6,12}
        };
        color = Color.WHITE;
		verticesList.add(vertices);
		facesList.add(faces);
		colorList.add(color);
		
		// Octahedron
		vertices = new double[][] {
      	  	{0,1,0},
      	  	{-0.5,0,0.5},
      	  	{-0.5,0,-0.5},
      	  	{0.5,0,-0.5},
      	  	{0.5,0,0.5},
      	  	{0,-1,0}
        };
        faces = new int[][] {
      	  	{0,4,1},
      	  	{0,1,2},
      	  	{0,2,3},
      	  	{0,3,4},
      	  	{5,4,1},
      	  	{5,1,2},
      	  	{5,2,3},
      	  	{5,3,4}
        };
        color = Color.BLUE;
		verticesList.add(vertices);
		facesList.add(faces);
		colorList.add(color);
	}
}