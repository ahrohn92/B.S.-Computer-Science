<!DOCTYPE HTML>
<html>
<?php
// Deletes User Session Variables When Logged Out
session_start(); 
unset($_SESSION['appUserName']); 
unset($_SESSION['appPassWord']); 

// Inserts New Username and Password into Wamp Database
if (isset($_POST["newusername"]) && isset($_POST["newpassword"])) {
	$newUserName = $_POST["newusername"];
	$newPassWord = $_POST["newpassword"];

	// Checks if Password is Valid
	include_once 'Includes/CheckPW.php';
	if ($validPassword == false) {
		include('registrationPage.php');
		echo "<p align='center'><b>Password does not meet the requirements.</b></p>";
	}
	else {
		// Checks to amke sure there are 3 selected security questions and all have answers
		include_once 'Includes/CheckSecurityQuestions.php';
		if ($sqCheck_1 == false) {
			include('registrationPage.php');
			echo "<p align='center'><b>Please select exactly 3 security questions.</b></p>";
		} else if ($sqCheck_2 == false) {
			include('registrationPage.php');
			echo "<p align='center'><b>Please answer all selected security questions.</b></p>";
		} else {
			// Inserts new username, password and security questions and answers to database
			include_once 'Includes/InsertNewPlayerDB.php';
			include('registrationPage.php');
			if ($uniqueUserCheck == false) {
				echo "<p align='center'><b>Username already exists. Please choose another.</b></p>";
			} else if ($uniquePassCheck == false) {
				echo "<p align='center'><b>Password already exists. Please choose another.</b></p>";
			} else {
				echo "<p align='center'><b>New user account was successfully created.<br>
						To login, return to the login page.</b></p>";
			}
		}
	}
} else {
?>
<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">   
   <title>Multiplication Complication &trade; - Login Page</title>
</head>
<body> 
	<h2 align="center">Welcome!<br>To play Multiplication Complication &trade; , please login.</h2>
	<br>
	<form name="login" method="post" action="securityQuestionPage.php">
	<table align="center" border="5">
	<tr>
		<th colspan="2">Login</th>
	</tr>
	<tr>
		<th>Username:</th>
		<td><input name="username" type="text" size="50"></td>
	</tr>
	<tr>
		<th>Password:</th>
		<td><input name="password" type="text" size="50"></td>
	</tr>
	<tr>
		<td colspan="2" align="center"><input name="submitbutton" type="submit" value="Login">
		<input name="resetbutton" type="reset" value="Reset"></td>
	</tr>
	</table>
	</form>
	<br><br>
	<h2 align="center">If you don't have an account please register one by clicking the link below.</h2>
	<p align="center"><a href='registrationPage.php'> Register </a></p>
</body>
<?php
}
?>
</html>

	