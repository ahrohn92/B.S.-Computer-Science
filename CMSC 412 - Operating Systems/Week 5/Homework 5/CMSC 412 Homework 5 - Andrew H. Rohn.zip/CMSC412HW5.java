import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.Scanner;

/*
 * Course:		CMSC 412
 * File:		CMSC412HW5.java
 * Author:		Andrew H. Rohn
 * Date:		20 Sep 2019
 * Purpose:		This program generates a text menu with options for the user to end
 * 				the program, select a directory, view the contents of a directory,
 * 				delete a file in the directory, view a file in hexadecimal notation,
 * 				and encrypt/decrypt a file.
 */

public class CMSC412HW5 {
	
	// Global Variables
	private static Integer userInput = null;
	private static boolean userInputIsValid = false;
	private static boolean createNewMenu = true;
	private static boolean encryptedFileFound = false;
	private static Scanner input;
	private static File selectedDirectory;
	private static ArrayList<String> encryptedFiles;
	
	// Main Method
	public static void main(String args[]) {
		
		// Checks if User Input is Valid
		while (userInputIsValid == false) {
			
			// Creates Initial Text Menu
			if (createNewMenu) {
				createMenu();
				createNewMenu = false;
			}
			
			// Starts Scanner for User Option
			input = new Scanner(System.in);
			try {
				userInput = input.nextInt();
				if (userInput >= 0 && userInput <= 7) {
					userInputIsValid = true;
					processUserInput(userInput);
				} else {
					userInputIsValid = false;
					System.out.print("Please enter an integer between 0 and 7: ");
				}
			} catch (InputMismatchException ime) {
				userInputIsValid = false;
				System.out.print("Please enter an integer between 0 and 7: ");
			}
		}
		input.close(); // Closes scanner
	}
	
	// Prints Text Menu to Console
	private static void createMenu() {
		System.out.println("\n--------------- USER OPTIONS ---------------\n");
		if (selectedDirectory != null) {
			System.out.println("Selected Directory: '"+selectedDirectory+"'\n");
		}
		System.out.println("0 - Exit");
		System.out.println("1 - Select Directory");
		System.out.println("2 - List Directory content (first level)");
		System.out.println("3 - List Directory content (all levels)");
		System.out.println("4 - Delete file");
		System.out.println("5 - Display file (hexidecimal view)");
		System.out.println("6 - Encrypt file (XOR with password)");
		System.out.println("7 - Decrypt file (XOR with password)");
		System.out.print("\nSelect option: ");
	}
	
	// Determines Program Function Based on User Input
	private static void processUserInput(int userInput) {
		switch(userInput) {
			case 0:	System.out.println("Program Ended");
				System.exit(0); // Exits Program
				break;
			case 1: 
				System.out.println("Option Selected: 1 - Select Directory");
				System.out.print("Enter the path of the directory: ");
				input = new Scanner(System.in);
				selectedDirectory = selectDirectory(input.nextLine());
				break;
			case 2: 
				if (selectedDirectory != null) {
					System.out.println("Option Selected: 2 - List Directory content (first level)");
					System.out.println("Contents of Selected Directory (first level):\n");
					System.out.println(selectedDirectory+" (Directory)");
					listDirectoryContents(selectedDirectory, 1);
				} else {
					System.out.println("\nPlease Select a Directory First (Option 1)");
				}
				break;
			case 3:
				if (selectedDirectory != null) {
					System.out.println("Option Selected: 3 - List Directory content (all levels)");
					System.out.println("Contents of Selected Directory (all levels):\n");
					System.out.println(selectedDirectory+" (Directory)");
					listDirectoryContents(selectedDirectory, 1);
				} else {
					System.out.println("\nPlease Select a Directory First (Option 1)");
				}
				break;
			case 4: 
				if (selectedDirectory != null) {
					System.out.println("Option Selected: 4 - Delete file");
					System.out.print("Enter the name of the file: ");
					input = new Scanner(System.in);
					deleteFile(input.nextLine());
				} else {
					System.out.println("\nPlease Select a Directory First (Option 1)");
				}
				break;
			case 5: 
				if (selectedDirectory != null) {
					System.out.println("Option Selected: 5 - Display file (hexadecimal view)");
					System.out.print("Enter the name of the file: ");
					input = new Scanner(System.in);
					displayHexadecimal(input.nextLine());
				} else {
					System.out.println("\nPlease Select a Directory First (Option 1)");
				}
				break;
			case 6: 
				if (selectedDirectory != null) {
					System.out.println("Option Selected: 6 - Encrypt file (XOR with password)");
					System.out.print("Enter a password: ");
					input = new Scanner(System.in);
					String password = input.nextLine();
					System.out.print("Enter the name of the file: ");
					input = new Scanner(System.in);
					XORCipher(input.nextLine(), password, true);
				} else {
					System.out.println("\nPlease Select a Directory First (Option 1)");
				}
				break;
			case 7: 
				if (selectedDirectory != null) {
					System.out.println("Option Selected: 7 - Decrypt file (XOR with password)");
					System.out.print("Enter a password: ");
					input = new Scanner(System.in);
					String password = input.nextLine();
					System.out.print("Enter the name of the file: ");
					input = new Scanner(System.in);
					XORCipher(input.nextLine(), password, false);
				} else {
					System.out.println("\nPlease Select a Directory First (Option 1)");
				}
				break;
			default: System.out.print("Please enter an integer between 0 and 7: ");
				break;
		}
		userInputIsValid = false;
		createNewMenu = true;
	}

	// Selects Directory (Option 1)
	private static File selectDirectory(String absolutePath) {
		File directory = new File(absolutePath);
		if (directory.exists()) {
			if (!directory.isDirectory()) {
				System.out.println("ERROR: '"+directory+"' is not a directory");
				return null;
			}
		} else {
			System.out.println("ERROR: directory '"+directory+"' does not exist");
			return null;
		}
		encryptedFiles = new ArrayList<String>();
		return directory;
	}
	
	// Displays Contents of Selected Directory (Options 2 & 3)
	private static void listDirectoryContents(File directory, int numTabs) {
		String tabs ="";
		for (int i = 0; i < numTabs; i++) {
			tabs += "\t";
		}
		for (File f : directory.listFiles()) {
			if (f.exists()) {
				if (f.isDirectory()) {
					System.out.println(tabs+"> "+f.getName()+" (Directory)");
					if (f.isDirectory() && userInput == 3) {
						listDirectoryContents(f, numTabs+1); // Recursion to Show all Levels
					}
				}
				if (f.isFile()) {
					System.out.println(tabs+"> "+f.getName()+" (File)");
				}
			}
		}
	}
	
	// Deletes File in Selected Directory (Option 4)
	private static void deleteFile(String fileName) {
		boolean fileFound = false;
		for (File f : selectedDirectory.listFiles()) {
			if (f.getName().equalsIgnoreCase(fileName)) {
				fileFound = true;
				try {
					f.delete();
				} catch (Exception e) {
					System.out.println("ERROR: file '"+fileName+"' could not be deleted");
				}
				System.out.println("The file '"+fileName+"' was successfully deleted");
			}
		}
		if (!fileFound) {
			System.out.println("ERROR: file '"+fileName+"' could not be found in directory '"+selectedDirectory+"'");
		}
	}
	
	// Displays File in Hexadecimal Notation (Option 5)
	private static void displayHexadecimal(String fileName) {
		try {
			FileInputStream fis = new FileInputStream(selectedDirectory+"\\"+fileName);
			System.out.println("\nThe hexadecimal notation of file '"+fileName+"' is:\n");
			int i = 0;
			int byteCount = 0;
			int dataOffset = 0;
			System.out.println("Offset  |  0  1  2  3  4  5  6  7  8  9  A  B  C  D  E  F");
			System.out.println("---------------------------------------------------------");
			System.out.print("00000000  "); // Initial Data Offset
			while ((i = fis.read())!= -1) {
				System.out.printf("%02X ", i);
				byteCount++;
				if (byteCount >= 16) {
					System.out.println("");
					dataOffset++;	
					 // Formats Data Offset
					System.out.print(String.format("%1$8s", Integer.toHexString(dataOffset).toUpperCase()+"0").replace(" ", "0")+"  ");
					byteCount = 0;
				}
			}
			System.out.println();
			fis.close();
		} catch (FileNotFoundException e1) {
			System.out.println("ERROR: file '"+fileName+"' could not be found in directory '"+selectedDirectory+"'");
		} catch (IOException e) {
			System.out.println("ERROR: file "+fileName+" could not be read");
		}
	}
	
	// Uses XOR Cryptography to Encrypt/Decrypt File (Options 6 & 7)
	private static void XORCipher(String fileName, String password, boolean isBeingEncrypted) {
		boolean fileFound = false;
		for (File f : selectedDirectory.listFiles()) {
			if (f.getName().equalsIgnoreCase(fileName)) {
				fileFound = true;
				Path path = Paths.get(selectedDirectory+"\\"+fileName);
				boolean run = true;
				
				// Checks if File is Already Encrypted
				for (int i = 0; i < encryptedFiles.size(); i++) {
					if (encryptedFiles.get(i).equals(fileName)) {
						encryptedFileFound = true;
						if (isBeingEncrypted) {
							System.out.println("ERROR: file '"+fileName+"' is already encrypted");
							run = false;
						}
					}
				}
				
				// Checks if File is Already Decrypted
				if (encryptedFileFound == false && isBeingEncrypted == false) {
					System.out.println("ERROR: file '"+fileName+"' is not encrypted");
					run = false;
				}
				
				// Checks if File is Already Decrypted
				if (run) {
					try {
						byte[] fileBytes = Files.readAllBytes(path);
						char[] fileBinary = new char[fileBytes.length*8];
						
						// Converts File Bytes to Binary
						int i = 0;
						for (byte fileByte : fileBytes) {
							String binary = String.format("%8s", 
									Integer.toBinaryString((fileByte+256)%256)).replace(" ", "0"); // Ensure binary code is 8 digits
							for (int j = 0; j < binary.length(); j++) {
								fileBinary[i] = binary.charAt(j);
								i++;
							}
						}
						
						byte[] passwordBytes = new byte[fileBytes.length];
						char[] passwordBinary = new char[passwordBytes.length*8];
						
						// Converts Password String to Bytes
						i = 0;
						int j = 0;
						while (passwordBytes[passwordBytes.length-1] == 0) {
							if (j >= password.getBytes().length) {
								j = 0;
							}
							passwordBytes[i] = password.getBytes()[j];
							i++;
							j++;
						}
						
						// Converts Password Bytes to Binary
						i = 0;
						for (byte passwordByte : passwordBytes) {
							String binary = String.format("%8s", 
									Integer.toBinaryString((passwordByte+256)%256)).replace(" ", "0"); // Ensure binary code is 8 digits
							for (j = 0; j < binary.length(); j++) {
								passwordBinary[i] = binary.charAt(j);
								i++;
							}
						}
						
						char[] XORBinary = new char[fileBinary.length];
						byte[] XORBytes = new byte[XORBinary.length/8];
						
						// Generates XOR Binary by Comparing File Binary and Password Binary
						for (i = 0; i < fileBinary.length; i++) {
							if (fileBinary[i] != passwordBinary[i]) {
								XORBinary[i] = '1';
							} else {
								XORBinary[i] = '0';
							}
						}
						
						// Converts XOR Binary to Bytes
						String binary = "";
						i = 0;
						for (j = 0; j < XORBinary.length; j++) {
							binary += XORBinary[j];
							if ((j+1) % 8 == 0) {
								XORBytes[i] = (byte) Integer.parseInt(binary, 2);
								binary = "";
								i++;
							}
						}
						
						// Writes Encrypted/Decrypted Data to File
						try (FileOutputStream fos = new FileOutputStream(path.toString())) {
							fos.write(XORBytes);
							fos.close();
							if (isBeingEncrypted) {
								System.out.println("File '"+fileName+"' was successfully encrypted");
								encryptedFiles.add(fileName);
							} else {
								System.out.println("File '"+fileName+"' was successfully decrypted");
								for (i = 0; i < encryptedFiles.size(); i++) {
									if (encryptedFiles.get(i).equals(fileName)) {
										encryptedFiles.remove(i);
									}
								}
							}
						} catch (Exception e) {
							if (isBeingEncrypted) {
								System.out.println("ERROR: encryption failed for file '"+fileName+"'");
							} else {
								System.out.println("ERROR: decryption failed for file '"+fileName+"'");
							}
							System.out.println("ERROR: Encryption/Decryption failed");
						}
					} catch (IOException e) {
						System.out.println("ERROR: file "+fileName+" could not be read");
					}
				}
			}
		}
		if (!fileFound) {
			System.out.println("ERROR: file '"+fileName+"' could not be found in directory '"+selectedDirectory+"'");
		}
		encryptedFileFound = false;
	}
}