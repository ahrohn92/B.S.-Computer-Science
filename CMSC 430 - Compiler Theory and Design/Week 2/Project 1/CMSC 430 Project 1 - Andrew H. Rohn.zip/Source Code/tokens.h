/*
 * Course:  	CMSC 430
 * File: 		tokens.h
 * Author: 		Andrew H. Rohn
 * Date: 		14 June 2019
 * Purpose: 	This file contains the enumerated type definition for tokens.
 */ 

enum Tokens {RELOP = 256, ADDOP, ARROW, BOOL_LITERAL, CASE, ELSE, ENDCASE, ENDIF, EXPOP, IF, MULOP, NOTOP, OROP, OTHERS, 
	ANDOP, BEGIN_, BOOLEAN, END, ENDREDUCE, FUNCTION, INTEGER, IS, REAL, REDUCE, REMOP, RETURNS, THEN, WHEN, IDENTIFIER, 
	INT_LITERAL, REAL_LITERAL};
