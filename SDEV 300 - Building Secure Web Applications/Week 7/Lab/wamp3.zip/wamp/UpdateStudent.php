<html>
	<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">   
   <title>Update Student </title>
</head>
<body > 

<?php   			

require_once('Includes/DBQueries.php');		
require_once('Includes/DBClasses.php');		

// Check to see if Delete name is provided
if (isset($_GET["psusername"])) {
  $toUpdate = $_GET["psusername"];
  // A bit dangerous without checks and use of getMethod
  updateIt($toUpdate);  
   
}
else if (isset($_POST["UpdateMe"])) {
	// Assign values
  $firstname = $_POST["firstname"];
  $lastname = $_POST["lastname"];
  $psusername = $_POST["psusername"];
  $email = $_POST["email"];
  
  $student = new StudentClass($firstname,$lastname,$email,$psusername);
  // Update the database
  FinalUpdate($student);
  
  // Successu message
   echo "<h3>$firstname $lastname has been updated!</h3> ";  
    echo "<p></p>";  
   echo "<a href='StudentApp.html'> Return to Student App.</a>";  
}
 else {
	    show_form();  	    
}
  	
	
function show_form() { 			
	
	echo "<p></p>";
	echo "<h2> Select the Student to Delete</h2>";
	echo "<p></p>";	 	
	// Retrieve the students
	$students = selectStudents();
	
	echo "<h3> " . "Number of Students in Database is:  " . sizeof($students) . "</h3>";
	// Loop through table and display
	echo "<table border='1'>";
	foreach ($students as $data) {
	echo "<tr>";	
	// Provide Hyperlink for Selection
	// Could also use Form with Post method 
	echo "<td> <a href=UpdateStudent.php?psusername=" . $data->getPsusername() . ">" . "Update" . "</a></td>";
	 echo "<td>" . $data->getFirstname() . "</td>";
	 echo "<td>" . $data->getLastname() . "</td>";
	 echo "<td>" . $data->getEmail() . "</td>";
	 echo "<td>" . $data->getPsusername() . "</td>";
	echo "</tr>";
}
	echo "</table>";

} // End Show form
?>

<?php
  	
 
  function updateIt($studentD) {
  	
  	
	$student = getStudent($studentD);
	// Extract data
	$firstname = $student->getFirstname();
	$lastname = $student->getLastname();
	$email = $student->getEmail();
	$psusername= $student->getPsusername();
	
	// Show the data in the Form for update
	?>
	<p></p>
	
	<form name="updateStudent" method="POST" action="UpdateStudent.php">	
	<table border="1" width="75%" cellpadding="0">			
			<tr>
				<td width="157">Firstname:</td>
				<td><input type="text" name="firstname" value='<?php echo $firstname ?>' size="30"></td>
			</tr>
			<tr>
				<td width="157">Lastname:</td>
				<td><input type="text" name="lastname" value='<?php echo $lastname ?>' size="30"></td>
			</tr>
			<tr>
				<td width="157">PS username:</td>
				<td><input type="text" name="psusername" value='<?php echo $psusername ?>' size="30"></td>
			</tr>
			<tr>
				<td width="157">Email:</td>
				<td><input type="text" name="email" value='<?php echo $email ?>' size="30"></td>
			</tr>
			<tr>
				<td width="157"><input type="submit" value="Update" name="UpdateMe"></td>
				<td>&nbsp;</td>
			</tr>
	</table>			
	</form>
		  	
  <?php	
  }
 
	 


?>
</body>
</html>
