import javax.swing.JOptionPane;

/*
 * Course:  	CMSC 451
 * File: 		UnsortedException.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 April 2019
 * Purpose: 	Constructs a JOptionPane prompt to alert the user if a data set failed to sort properly.
 */

public class UnsortedException extends Exception {
    public UnsortedException(String message) {
		JOptionPane.showMessageDialog(null, 
				message, "Error", JOptionPane.ERROR_MESSAGE);
    }
}