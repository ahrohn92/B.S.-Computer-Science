<!DOCTYPE HTML>
<html>
<?php
session_start();

$userName = $_SESSION['appUserName'];
$passWord = $_SESSION['appPassWord'];

?>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
	<title>Multiplication Complication &trade; - Update User Info Page</title>
</head>
<body>
<?php
	$securityQuestions = array("What is your favorite color?", "What city was your father born in?",
	"What was the name of your first pet?", "What is your favorite band?", "What is first name of your first kiss?",
	"Who was your third grade teacher?", "Who is your favorite author?", "What was the year of your first car?",
	"What is your favorite sports team?", "How many siblings do you have?");
?>
	<form name='loginreturn' method='post' action='loginPage.php'> 
			<input name='loginreturnbutton' type='submit' value='Return to Login Page'>
	</form>
	<form name="updateinfo" method="post" action="updatePage2.php">  
	<h1 align="center">Enter your new user information</h1>
	<h2 align="center">In order to update your account you must create a new unique username and password.</h2>
	<table align="center" border="1">
		<tr>
			<th>Username</th>
			<td><input name="updateusername" type="text" size="30"></td>
		</tr>
		<tr>
			<th>Password</th>
			<td><input name="updatepassword" type="text" size="30"></td>
		</tr>
	</table>
	<br><br>
	<table align="center">
		<tr><td><b>Rules for Password:</b></td></tr>
		<tr><td>- Must be at least 8 characters in length</td></tr>
		<tr><td>- Must have at least one uppercase letter</td></tr>
		<tr><td>- Must have at least one number</td></tr>
		<tr><td>- Must have at least one special character (e.g. !@#$%)</td></tr>
	</table>
	<br><br>
	<h1 align="center">Security Questions</h1>
	<h3 align="center">Please select 3 security questions and input an answer for each.</h3>
	<table align="center">
	<tr>
		<th>Security Question</th>
		<th>Answer</th>
	</tr><tr></tr>
		<?php 
		// Security Questions Table
		for ($i = 0; $i < 10; $i++) {
		?>
		<tr>
			<td><input type="checkbox" name="securityquestions[<?php echo $i; ?>]" value="<?php echo $securityQuestions[$i]; ?>" /> <?php echo $securityQuestions[$i]; ?></td>
			<td><input name="answer_<?php echo $i; ?>" type="text" size="50"></td>
		</tr>
		<?php 
		} 
		?>
	<tr>
		<td colspan="3" align="center"><input name="submitbutton" type="submit" value="Update">
		<input name="resetbutton" type="reset" value="Reset"></td>
	</tr>
	</table>
	</form>
</body>
</html>
