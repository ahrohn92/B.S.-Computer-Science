@extends('layouts.app')
@section('content')
<div class="container">
    <h1>Guide</h1>
    <h3>This is where I will place the guide for API usage</h3>
</div>
@endsection
