/*
 * Course:  	CMSC 451
 * File: 		SortInterface.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 April 2019
 * Purpose: 	Required by Project prompt.
 */

public interface SortInterface {
    int[] iterativeSort(int[] list) throws UnsortedException;
    int[] recursiveSort(int[] list) throws UnsortedException;
    int getCount();
    long getTime();
}