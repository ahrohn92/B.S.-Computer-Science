import java.util.*;
import java.io.*;

/*
 * Course:  	CMSC 350
 * File: 		DirectedGraph.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 December 2018
 * Purpose: 	Generic class that defines the directed graph and contains methods for sorting vertices
 * 	 			in topological order with a recursive depth first search method.
 */

public class DirectedGraph <V> {
	
	// Instance Variables for Building Directed Graph
	
    // Number of Unique Vertices in Read File
    private int numVertices;
    
	// Array List that Contains the Names of Vertices
	private ArrayList<V> vertexNames = new ArrayList<V>();
	
	// Linked List that Contains the Edges to Adjacent Vertices for Each Vertex
    private LinkedList<Integer>[] associatedAdjacencyList;
    
    // Hash Map that Links the Names of Vertices with an Index Number
    private HashMap<V,Integer> vertexHashMap = new HashMap<>();
    
    // Stack Data Structure for Sorting Vertices in Topological Order
    private IndexStack<Integer> stack = new IndexStack<Integer>();

    // Method that Builds Directed Graph Using Adjacency List To Connect Vertices with Edges
	public void buildDirectedGraph (String fileName) throws IOException {
        	
        	// File Path for Read File
        	String filePath = "C:/Users/Matthew/Desktop/"+fileName;
        	
            // Initialization of Scanner for Read File
			Scanner input = new Scanner(new File(filePath));
            
			// Initialization of Index Counter
			int index = 0;
			
			// For Each Line in Read File...
            while (input.hasNext()) {
 
                // Splits Words of Each Line and Saves Them in Array 
                String[] vertexName = input.nextLine().split(" ");
                
                // Adds Each Vertex Name and Index Number to HashMap
                for (int i = 0; i < vertexName.length; i++) {
                	
                	V vertex = (V)vertexName[i];
                	
                	// Checks to See if Vertex is Already in HashMap 
                	if(!vertexHashMap.containsKey(vertex)) {
                		
                		// If Not, New Vertex and Index Number Are Added to HashMap
                		vertexHashMap.put(vertex,index);
                		
                		// Adds New Vertex Name to ArrayList + Increments Index
                		vertexNames.add(vertex);
                		numVertices++;
                		index++;
                	}
                }     
            }

            // Associated Adjacency List Links to Vertex Index Number in Hash Map
            associatedAdjacencyList = new LinkedList[numVertices]; 
            
            // Reinitializes Scanner for Second Scan of Read File
            Scanner input2 = new Scanner(new File(filePath));
            
            // Scans the Read File Again to Create the Adjacency List
            while (input2.hasNext()) {
            	
            	// Splits Words of Each Line and Saves Them in Array
                String[] vertexName = input2.nextLine().split(" ");
                                
                // The First Vertex on Each Line of Read File is the Root Vertex
                V rootlVertex = (V) vertexName[0];
               
                // Creates a Linked List for Edges Connected to Root Vertex on Each Line
                associatedAdjacencyList[vertexHashMap.get(rootlVertex)] = new LinkedList<Integer>();
            	
            	// The Remaining Vertices are Dependent on the Root Vertex 
                for (int i = 1; i < vertexName.length; i++) {
                	
                	V dependentVertex =  (V) vertexName[i];
                	
                	// If Both the Root Vertex and the Dependent Vertex Exist in the Hash Map...
                    if(vertexHashMap.containsKey(rootlVertex) && vertexHashMap.containsKey(dependentVertex)) {

                 	   // The Dependent Vertex is Added to the Associated Adjacency List of the Root Vertex.
                 	   associatedAdjacencyList[vertexHashMap.get(rootlVertex)].add(vertexHashMap.get(dependentVertex));
                    }
                }    
            }      
    }

	// Method Sorts Root Vertices in Topological Order
    public String sortTopologicalOrder (V rootVertex) throws InvalidClassNameException, CycleDetectedException {
    	
        // An Invalid Class Name Exception is Thrown if Root Vertex Doesn't Exist in Hash Map
        if (!vertexHashMap.containsKey(rootVertex)) {
        	throw new InvalidClassNameException();
        }
        
        // If It Exists...
        else {
        	try {
        		
        		// Boolean Array That Determines if Vertex Already Exists in the Graph to Detect Cycles
            	boolean alreadyExists[]= new boolean[numVertices];
            	
            	// Boolean Array That Determines if DFS has Ended for a Vertex
                boolean sortEnd[]= new boolean[numVertices];
                
	        	// Calls DFS Method to Sort the Graph by Reverse Topological Order
				depthFirstSearch (vertexHashMap.get(rootVertex), alreadyExists, sortEnd);

				// Initialization of Sorted Order String for Output
	            String recompilationOrder = "";
	            
	            // While Stack has Indices...
	            while (stack.notEmpty()) {
	            	
	            	// Pop Most Recent Index on Top of Stack
	            	int poppedIndex = (int) stack.popIndex();
	               
	               	// Use the vertices ArrayList<String> to retrieve the name of the vertex at the specified index position of the popped integer. 
	            	V vertexName = vertexNames.get(poppedIndex);
	                
	                // Adds Vertex Name (Class) to Recompilation Order 
	            	recompilationOrder += vertexName+" ";
	            }
	            return recompilationOrder;
			} catch (Exception e3) {
				
	        	// Throws CycleDetectedException if Cycle Is Detected 
	        	throw  new CycleDetectedException();
			}
        }
    }
    
    // Depth First Search Method that Generates a Reverse Topological Order of the Graph
    private void depthFirstSearch (int rootIndex, boolean alreadyExists[], boolean sortEnd[]) throws CycleDetectedException {
    	
    	// If Root Node Already Exists, a Cycle is Detected
        if (alreadyExists[rootIndex] == true) {
        	
        	// A New Stack Instance is Initiated, Eliminating Previous Vertex Indices
        	stack = new IndexStack<Integer>();
        	
        	// Throws CycleDetectedException
        	throw new CycleDetectedException();
        }      
        
        // If Sorting is Done, DFS Method is Exited
        if(sortEnd[rootIndex] == true) {
            return;
        }
        
        // Root Vertex Index Exists
        alreadyExists[rootIndex] = true;

        // If Associated Adjacency List is Not Null For Root Index...
        if (associatedAdjacencyList[rootIndex]!= null) {

        	// A Recursive DFS is Initiated for Each Adjacent Vertex
        	for (int adjacentVertex: associatedAdjacencyList[rootIndex]) {
        		depthFirstSearch (adjacentVertex, alreadyExists, sortEnd);
        	}
        }
        
        // Root Vertex Index is Sorted
        sortEnd[rootIndex] = true;
        
        // Root Vertex Index is Pushed onto Stack
        stack.pushIndex(rootIndex);
    }
}