<?php

// Checks Length of Password
if (strlen($newPassWord) >= 8) {
	$check_1 = true;
} else {
	$check_1 = false;
}	

// Checks If Password Contains one uppercase
if (preg_match('/[A-Z]/', $newPassWord)) {
	$check_2 = true;
} else {
	$check_2 = false;
}

// Checks If Password Contains one number
if (preg_match('/[0-9]/', $newPassWord)) {
	$check_3 = true;
} else {
	$check_3 = false;
}

// Checks If Password Contains one special char
if (preg_match('/[\'\/~`\!@#\$%\^&\*\(\)_\-\+=\{\}\[\]\|;:"\<\>,\.\?\\\]/', $newPassWord)) {
	$check_4 = true;
} else {
	$check_4 = false;
}

// Checks if all other checks are good
if ($check_1 && $check_2 && $check_3 && $check_4) {
	$validPassword = true;
} else {
	$validPassword = false;
}
?>
