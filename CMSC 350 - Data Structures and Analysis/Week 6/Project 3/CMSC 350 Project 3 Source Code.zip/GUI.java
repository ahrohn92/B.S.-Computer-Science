import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/*
 * Course:  	CMSC 350
 * File: 	GUI.java
 * Author: 	Andrew H. Rohn
 * Date: 	1 December 2018
 * Purpose: 	Contains Main Method that builds GUI
 */

public class GUI extends JFrame {

    // Components for Panels
	JLabel originalListLabel = new JLabel("Original List");
	JLabel sortedListLabel = new JLabel("Sorted List");
    JTextField originalListTextField = new JTextField("", 20);
    JTextField sortedListTextField = new JTextField("", 20);
    JButton button = new JButton("Perform Sort");
    JRadioButton ascendingRadioButton = new JRadioButton("Ascending");
    JRadioButton descendingRadioButton = new JRadioButton("Descending");
    JRadioButton integerRadioButton = new JRadioButton("Integer");
    JRadioButton fractionRadioButton = new JRadioButton("Fraction");
	
    // Constructor for GUI
    private GUI() {

        // Creation of Original List Panel
        JPanel originalListPanel = new JPanel();
        originalListPanel.add(originalListLabel);
        originalListPanel.add(originalListTextField);
        originalListPanel.setPreferredSize(new Dimension(500,65));
        
        // Creation of Sorted List Panel
        JPanel sortedListPanel = new JPanel();
        sortedListPanel.add(sortedListLabel);
        sortedListPanel.add(sortedListTextField);
        sortedListTextField.setEditable(false);
        
        // Creation of Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.add(button);
        buttonPanel.setLayout(new GridBagLayout());
        
        // Creation of Sort Order Button Group
        ButtonGroup sortOrderButtonGroup = new ButtonGroup();
        sortOrderButtonGroup.add(ascendingRadioButton);
        sortOrderButtonGroup.add(descendingRadioButton);
        ascendingRadioButton.setSelected(true);
        
        // Creation of Sort Order Panel
        JPanel sortOrderPanel = new JPanel();
        sortOrderPanel.setBorder(BorderFactory.createTitledBorder("Sort Order"));
        sortOrderPanel.add(ascendingRadioButton);
        sortOrderPanel.add(descendingRadioButton);
        sortOrderPanel.setLayout(new BoxLayout(sortOrderPanel, BoxLayout.Y_AXIS));
        
        // Creation of Numeric Type Button Group
        ButtonGroup numericTypeButtonGroup = new ButtonGroup();
        numericTypeButtonGroup.add(integerRadioButton);
        numericTypeButtonGroup.add(fractionRadioButton);
        integerRadioButton.setSelected(true);
        
        // Creation of Numeric Type Panel
        JPanel numericTypePanel = new JPanel();
        numericTypePanel.setBorder(BorderFactory.createTitledBorder("Numeric Type"));
        numericTypePanel.add(integerRadioButton);
        numericTypePanel.add(fractionRadioButton);
        numericTypePanel.setLayout(new BoxLayout(numericTypePanel, BoxLayout.Y_AXIS));
        
        // Creation of Radio Button Panel (Sort Order + Numeric Type Panels)
        JPanel radioButtonPanel = new JPanel();
        radioButtonPanel.add(sortOrderPanel);
        radioButtonPanel.add(numericTypePanel);
        radioButtonPanel.setLayout(new GridLayout());
        
        // Creation of Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.add(originalListPanel);
        mainPanel.add(sortedListPanel);
        mainPanel.add(buttonPanel);
        mainPanel.add(radioButtonPanel);
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        add(mainPanel);

        // Action Listener for Button
        button.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {

        	// Saving Input as String
            String originalList = originalListTextField.getText();

            try {
                if (originalList.isEmpty()) {
                    throw new NullPointerException();
                } else {
                	
                	// Initialization of Sorted List String
                	String sortedList = null;
                	
                	// Tokenization of Original List
                	String[] tokens = originalList.split(" ");

                	// Action Event for Integer Radio Button
                	if (integerRadioButton.isSelected()) {
                		
                		// Creates BST Instance for Integer Numeric Type
                		BinarySearchTree<Integer> bst = new BinarySearchTree<>();
                		// Turns Tokens into New Nodes
                		for (String token : tokens) {
                			bst.newNode(Integer.parseInt(token));
                		}

                		// Creates Sorted List in either Ascending or Descending Order
                		if (ascendingRadioButton.isSelected()) {
                			sortedList = bst.ascendingOrder();
                		} else if (descendingRadioButton.isSelected()) {
                			sortedList = bst.descendingOrder();
                		}
                	}

                	// Action Event for Fraction Radio Button
                	if (fractionRadioButton.isSelected()) {

                		// Creates BST Instance for Fraction Numeric Type
                		BinarySearchTree<Fractions> bst = new BinarySearchTree<>();

                		// Turns Tokens into New Nodes w/ Fraction Values
                		for (String token : tokens) {
                			Fractions fraction = new Fractions(token);
                			bst.newNode(fraction);
                		}
                		
                		// Creates Sorted List in either Ascending or Descending Order
	                    if (ascendingRadioButton.isSelected()) {
	                    	sortedList = bst.ascendingOrder();
	                    } else if (descendingRadioButton.isSelected()) {
	                    	sortedList = bst.descendingOrder();
	                    }
                	}

                // Sorted List is Displayed in Sorted List Text Field
                sortedListTextField.setText(sortedList);
                }
            // Checked Exception Methods
            } catch (NullPointerException nullPointer) {
                JOptionPane.showMessageDialog(null, "Please enter a list to be sorted.","ERROR!",
                		JOptionPane.ERROR_MESSAGE);
            } catch (NumberFormatException numberFormat) {
                JOptionPane.showMessageDialog(null, numberFormat.getMessage()+"\nInvalid Input."
                		+ "\nPlease enter a valid numeric expression.","ERROR!",
                		JOptionPane.ERROR_MESSAGE);
            }
        }
    });
    }

    // Main Method
    public static void main(String[] args) {

       GUI frame = new GUI();
       
       // Parameters for GUI frame
       frame.setTitle("Binary Search Tree Sort");
       frame.setSize(400,300);
       frame.setLocationRelativeTo(null);
       frame.setResizable(false);
       frame.setVisible(true);
       frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}