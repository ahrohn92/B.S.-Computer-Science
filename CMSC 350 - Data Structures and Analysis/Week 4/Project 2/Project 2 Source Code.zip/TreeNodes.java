import java.io.IOException;

/*
 * Course:  	CMSC 350
 * File: 	TreeNodes.java
 * Author: 	Andrew H. Rohn
 * Date: 	18 November 2018
 * Purpose: 	Abstract class that creates the arithmetic expression tree
 */

public interface TreeNodes {
	
    String traverseInOrder();
    String traversePostOrder() throws IOException;
    void newTraversal() throws IOException;
    
}