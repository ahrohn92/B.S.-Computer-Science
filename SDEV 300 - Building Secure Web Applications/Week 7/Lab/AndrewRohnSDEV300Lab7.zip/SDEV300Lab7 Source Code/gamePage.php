<!--
Date: Dec 8, 2018 
Author: Andrew H. Rohn  
Title: gamePage.php  
Description: Game Page
-->

<!DOCTYPE HTML>

<html>
<?php
session_start();
$tAnswer = $_POST["randomquestionanswer"];

if (strcasecmp($tAnswer,$_SESSION['appSecurityAnswer']) != 0) {
	include('loginPage.php');
	echo "<p align='center'><b>The answer you gave is not correct.<br> Please try to login again.</b></p>";
} else {
?>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
	<title>Multiplication Complication &trade; - Game Page</title>
</head>
<?php

// Mathematical Equations
$num1_array = array(20);
$num2_array = array(20);
$product_array = array(20);

for ($i = 0; $i < 20; $i++) {
	$num1_array[$i] = rand(1,100);
	$num2_array[$i] = rand(1,100);
	$product_array[$i] = $num1_array[$i] * $num2_array[$i];
}	

$_SESSION['appNum1_Array'] = $num1_array;
$_SESSION['appNum2_Array'] = $num2_array;
$_SESSION['appProduct_Array'] = $product_array;

// Finds Player with highest score and displays him/her on game page
include_once 'Includes/FindHighestScoreDB.php';

$_SESSION['appUserHighScore'] = $userHighScore;
$_SESSION['appHighScore'] = $highScore;

?>
<body>
<form name='logout' method='post' action='loginPage.php'> 
		<input name='logoutbutton' type='submit' value='Logout'>
</form>
<form name='update' method='post' action='updatePage.php'> 
		<input name='updatebutton' type='submit' value='Update Account'>
</form>
<form name='delete' method='post' action='deletePage.php'> 
		<input name='updatebutton' type='submit' value='Delete Account'>
</form>
	<!-- Table Displays User w/ Highest Score -->
	<h3>High Score:</h3>
	<table border="5">
		<tr>
			<th>Username </th>
			<th>Score </th>
		</tr>
		<tr>
			<td><?php echo $userHighScore; ?></td>
			<td><?php echo $highScore; ?></td>
		</tr>
	</table>
	<h1>Welcome, <?php echo $_SESSION['appUserName']; ?> to a game of Multiplication Complication!</h1>
	<h2>Let's see if you can beat <?php echo $userHighScore; ?>'s score.</h2>
	<form name="quiz" method="post" action="scorePage.php">
	<?php for ($i = 0, $j = 1; $i < 20; $i++, $j++) {
	?>
	<table class="fixed" border="5">
		<col width="150px"/>
		<tr>
			<td colspan="2"><b>Question #<?php echo $j; ?></b></td>
		</tr>
		<tr>
			<td>What is <?php echo $num1_array[$i]; ?> x <?php echo $num2_array[$i]; ?>?</td>
			<td><input name="answer_<?php echo $i; ?>" type="text" size="7"></td>
		</tr>
	</table><br><br>
	<?php
	}
	?>
	<input name="submitbutton" type="submit" value="Submit">
	</form>
</body>
<?php
}
?>
</html>
