import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

/*
 * Course:  	CMSC 350
 * File: 		GUI.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 December 2018
 * Purpose: 	Contains Main Method that builds GUI. It also handles checked exceptions.
 */

public class GUI extends JFrame {

    // Components for Panels
    JLabel fileLabel = new JLabel("Input file name:");
    JLabel classLabel = new JLabel("Class to recompile:");
    JTextField fileTextField = new JTextField("",15);
    JTextField classTextField = new JTextField("",15);
    JButton buildGraphButton = new JButton("Build Directed Graph");
    JButton topologicalOrderButton = new JButton("Topological Order");
    JTextArea outputTextArea = new JTextArea();
    JScrollPane scrollPane = new JScrollPane(outputTextArea);
    
    // Constructor for GUI
    private GUI() {
    	
        // Creation of Label Panel
        JPanel labelPanel = new JPanel();
        labelPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 10));
        labelPanel.add(fileLabel);
        labelPanel.add(classLabel);
        
        // Creation of Text Field Panel
        JPanel textFieldPanel = new JPanel();
        textFieldPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 10));
        textFieldPanel.add(fileTextField);
        textFieldPanel.add(classTextField);
        
        // Creation of Button Panel
        JPanel buttonPanel = new JPanel();
        buttonPanel.setLayout(new FlowLayout(FlowLayout.CENTER, 0, 8));
        buttonPanel.add(buildGraphButton);
        buttonPanel.add(topologicalOrderButton);
        
        // Creation of Input Panel (Label + Text Field + Button Panels)
        JPanel inputPanel = new JPanel();
        inputPanel.setBorder(BorderFactory.createTitledBorder(" "));
        inputPanel.setLayout(new GridLayout(1,3,5,0));
        inputPanel.setPreferredSize(new Dimension(50, 95));
        inputPanel.add(labelPanel);
        inputPanel.add(textFieldPanel);
        inputPanel.add(buttonPanel);
        
        // Creation of Output Panel
        JPanel outputPanel = new JPanel();
        outputPanel.setBorder(BorderFactory.createTitledBorder("Recompilation Order"));
        outputPanel.setLayout(new BorderLayout());
        outputPanel.setBackground(Color.WHITE);
        outputTextArea.setLineWrap(true);
        outputTextArea.setWrapStyleWord(true);
        outputTextArea.setEditable(false);
        outputPanel.add(scrollPane);

        // Creation of Main Panel
        JPanel mainPanel = new JPanel();
        mainPanel.setLayout(new BoxLayout(mainPanel, BoxLayout.Y_AXIS));
        mainPanel.add(inputPanel);
        mainPanel.add(outputPanel);
        add(mainPanel);
        
        
        // Initialization of Class Object for Directed Graph
        DirectedGraph<String> directedGraph = new DirectedGraph<>();
        
        
        // Action Listener for "Build Directed Graph" Button
        buildGraphButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {
        		
        	// Saves Input as String
        	String fileName = fileTextField.getText();

            try {
            	
            	// Throws NullPointerException if No File is Inputed
                if (fileName.isEmpty()) {
                    throw new NullPointerException();
                } else {

                // Builds Directed Graph from Read File
                directedGraph.buildDirectedGraph(fileName);
                
                // Message Appears Upon Successful Construction of Directed Graph
                JOptionPane.showMessageDialog(null, "Graph Built Successfully", "Message", JOptionPane.INFORMATION_MESSAGE);
                }
                
            // Checked Exceptions for Read File Input
            } catch (NullPointerException e1) {
                JOptionPane.showMessageDialog(null, "A File Name is Required", "Error", JOptionPane.ERROR_MESSAGE);
            } catch (IOException e2) {
                JOptionPane.showMessageDialog(null, "File Did Not Open", "Error", JOptionPane.ERROR_MESSAGE);
            }
        	}
        });

        // Action Listener for "Topological Order" Button
        topologicalOrderButton.addActionListener(new ActionListener() {
        	public void actionPerformed(ActionEvent e) {

        	// Saves Input as String
           	String className = classTextField.getText();

            try {
            	
            	// Throws NullPointerException if No Class is Inputed
            	if (className.isEmpty()) {
            		throw new NullPointerException();
            	} else {
            		
            		// Retrieves Recompilation Order for Output
            		String recompilationOrder =  directedGraph.sortTopologicalOrder(className);
            		outputTextArea.setText(recompilationOrder);
            	}
            
            // Checked Exceptions for Invalid Class Name and Cycle Detection
            } catch (InvalidClassNameException e1) {
                JOptionPane.showMessageDialog(null, "Invalid Class Name: "+className, "Error", JOptionPane.ERROR_MESSAGE);
            } catch (CycleDetectedException e2) {
                JOptionPane.showMessageDialog(null, "This Graph Contains a Cycle", "Error", JOptionPane.ERROR_MESSAGE);
            }
        	}
        });
    }

    // Main Method
    public static void main(String[] args) {

    	GUI frame = new GUI();
        
        // Parameters for GUI Frame
        frame.setTitle("Class Dependency Graph");
        frame.setSize(550,300);
        frame.setLocationRelativeTo(null);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
    }
}
