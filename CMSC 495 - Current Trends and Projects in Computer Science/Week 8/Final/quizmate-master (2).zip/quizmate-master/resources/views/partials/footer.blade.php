<footer class="footer">
  <div>
    <p>Created by: CleanCodeClub</p>
  </div>
</footer>
