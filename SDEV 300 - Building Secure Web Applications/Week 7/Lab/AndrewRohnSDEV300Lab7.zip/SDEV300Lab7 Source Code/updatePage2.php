<!DOCTYPE HTML>
<html>
<?php
// Starts Session
session_start(); 

// Updates New Username and Password into Wamp Database
if (($_POST["updateusername"] != '') && ($_POST["updatepassword"] != '')) {
	$newUserName = $_POST["updateusername"];
	$newPassWord = $_POST["updatepassword"];

	// Checks if Password is Valid
	include_once 'Includes/CheckPW.php';
	if ($validPassword == false) {
		include('updatePage.php');
		echo "<p align='center'><b>Password does not meet the requirements.</b></p>";
	}
	else {
		// Checks to amke sure there are 3 selected security questions and all have answers
		include_once 'Includes/CheckSecurityQuestions.php';
		if ($sqCheck_1 == false) {
			include('updatePage.php');
			echo "<p align='center'><b>Please select exactly 3 security questions.</b></p>";
		} else if ($sqCheck_2 == false) {
			include('updatePage.php');
			echo "<p align='center'><b>Please answer all selected security questions.</b></p>";
		} else {
			// Updates new username, password and security questions and answers to database
			include_once 'Includes/UpdatePlayerDB.php';
			include('updatePage.php');
			if ($uniqueUserCheck == false) {
				echo "<p align='center'><b>Username already exists. Please choose another.</b></p>";
			} else if ($uniquePassCheck == false) {
				echo "<p align='center'><b>Password already exists. Please choose another.</b></p>";
			} else {
				echo "<p align='center'><b>Your user account was successfully updated.<br>
						You will need to login again with your new username and password.</b></p>";
			}
		}
	}
} else {
	include('updatePage.php');
	echo "<p align='center'><b>Please enter a new username and password.</b></p>";
}
?>

</html>