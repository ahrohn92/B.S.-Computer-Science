
/*
 * Course:  	CMSC 412
 * File: 		CMSC412HW3.java
 * Author: 		Andrew H. Rohn
 * Date: 		8 Sep 2019
 * Purpose: 	This class creates 3 separate threads and uses flags in order to
 * 				synchronize the threads in such a way that they each take turns printing
 * 				their thread number as well as the current iteration five times.
 */

public class CMSC412HW3 {
	
	// Global Variables
	private Thread thread1, thread2, thread3;
	private int nextThreadNumber = 1;
	
	// Creates Three Separate Threads With Executable Code
	private void createThreads() {
		thread1 = new Thread(new Runnable() {
			public void run() {
				int i = 1;
				while (i <= 5) {
					if (displayIteration(1,i) == true) {
						i++;
					}
				}
			}
		});
		thread2 = new Thread(new Runnable() {
			public void run() {
				int i = 1;
				while (i <= 5) {
					if (displayIteration(2,i) == true) {
						i++;
					}
				}
			}
		});
		thread3 = new Thread(new Runnable() {
			public void run() {
				int i = 1;
				while (i <= 5) {
					if (displayIteration(3,i) == true) {
						i++;
					}
				}
			}
		});
	}
	
	// Starts the Threads
	private void startThreads() {
		thread1.start();
		thread2.start();
		thread3.start();
	}
	
	// Displays Thread and Iteration Numbers
	private synchronized boolean displayIteration(int threadNumber, int iteration) {
		if (nextThreadNumber > 3) {
			nextThreadNumber = 1;
		}
		if (nextThreadNumber == threadNumber) {
			System.out.println("Thread "+threadNumber+" - iteration no. "+iteration);
			nextThreadNumber++;
			return true;
		} else {
			return false;
		}
	}
	
	// Main Method
	public static void main(String args[]) {
		CMSC412HW3 main = new CMSC412HW3();
		main.createThreads();
		main.startThreads();
	}
}
