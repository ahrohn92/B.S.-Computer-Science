<!DOCTYPE HTML>
<?php
session_start();
$score = 0;
$answer_array = array(20);

for ($i = 0; $i < 20; $i++) {
	$answer_array[$i] = $_POST["answer_".$i.""];
}	
?>

<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8"> 
	<title>Multiplication Complication &trade; - Result Page</title>
</head>
<form name='logout' method='post' action='loginPage.php'> 
		<input name='logoutbutton' type='submit' value='Logout'>
</form>
<form name='update' method='post' action='updatePage.php'> 
		<input name='updatebutton' type='submit' value='Update Account'>
</form>
<form name='delete' method='post' action='deletePage.php'> 
		<input name='updatebutton' type='submit' value='Delete Account'>
</form>
<body>
	<h1 align="center">Your Results!</h1>
	<table align="center" border="1">
	<tr>
		<th>Your Answers</th>
		<th>Correct Answers</th>
	</tr>
	<?php
	for ($i = 0; $i < 20; $i++) {
	?>
		<tr>
			<td><?php 
				if ($answer_array[$i] != $_SESSION['appProduct_Array'][$i]) {
					?><font color="red"><?php echo $answer_array[$i];?></font><?php
				} else {
					?><font color="green"><?php echo $answer_array[$i];?></font><?php 
				}?></td>
			<td><?php echo $_SESSION['appProduct_Array'][$i]; ?></td>
		</tr>
	<?php
		// Calculates Score of Game
		if ($answer_array[$i] == $_SESSION['appProduct_Array'][$i]) {
			$score++;
		}
	}
	?>
	</table>
<br><br><p align="center"><b>Your score is <?php echo $score; ?> out of 20.<b></p><br>
<?php

// Tells player whether or not they beat the current high score
if ($score > $_SESSION['appHighScore']) {
	echo "<p align='center'><b>Congratulations!<br>You beat ".$_SESSION['appUserHighScore']."'s 
	high score.<br>You now have the highest score.</b></p>";
}
if ($score == $_SESSION['appHighScore']) {
	echo "<p align='center'><b>You tied with ".$_SESSION['appUserHighScore']."</b></p>";
} 
if ($score < $_SESSION['appHighScore']) {
	echo "<p align='center'><b>Sorry!<br>You did not beat ".$_SESSION['appUserHighScore']."'s score.</b></p>";
}	

$userCurrentHighScore = array(1);
include_once 'Includes/CheckUserHighScoreDB.php';
if ($score > $userCurrentHighScore[0]) {
	//Update Score
	include_once 'Includes/UpdateHighScoreDB.php';
}
?>
</body>
</html>
