<html>
	<head>
   <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">   
   <title>Select Student </title>
</head>
<body OnLoad="document.createstudent.firstname.focus();"> 

<?php   			

	require_once('Includes/DBQueries.php');		
	
	show_form(); 
   
			
	function show_form() { 			
		
		echo "<p></p>";
		echo "<h2> The Current Students</h2>";
		echo "<p></p>";	 	
		// Retrieve the students
		$students = selectStudents();
		
		echo "<h3> " . "Number of Students in Database is:  " . sizeof($students) . "</h3>";
		// Loop through table and display
		echo "<table border='1'>";
		// Table headers
		echo "<tr> <td><b> Firstname</b> </td>";
		echo "<td> <b>Lastname</b> </td>";
		echo "<td><b> Email</b> </td>";
		echo "<td> <b>PSUsername</b> </td> </tr>";
		
		foreach ($students as $data) {
		echo "<tr>";	
		 echo "<td>" . $data->getFirstname() . "</td>";
		 echo "<td>" . $data->getLastname() . "</td>";
		 echo "<td>" . $data->getEmail() . "</td>";
		 echo "<td>" . $data->getPsusername() . "</td>";
		echo "</tr>";
	  }
		echo "</table>";
	
	} // End Show form
	 echo "<p></p>"; 
	 echo "<a href='StudentApp.html'> Return to Student App.</a>";  
?>

</body>
</html>
