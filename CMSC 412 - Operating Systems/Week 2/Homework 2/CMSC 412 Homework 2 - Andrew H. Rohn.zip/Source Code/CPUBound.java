import java.util.Random;

/*
 * Course:  	CMSC 412
 * File: 		CPUBound.java
 * Author: 		Andrew H. Rohn
 * Date: 		1 Sep 2019
 * Purpose: 	This class uses a distinct thread to sum 1000 computations of 3 randomly generated integers with
 *				values between 1 and 10. The run time of the thread is returned to the Controller class.
 */

public class CPUBound implements Runnable {

	// Instance Variables
	private int threadNumber;
	private long startTime, runTime;
	private boolean isFinished = false;
	
	// Constructor
	public CPUBound(int threadNumber) {
		this.threadNumber = threadNumber;
	}

	// Thread's Executable Code
	public void run() {
	
		System.out.println("CPU Bound Thread #"+threadNumber+" has started");
		startTime = System.nanoTime(); // Start Time
		
		// Summation of 1000 Computations of 3 Random Integers With Values Between 1 and 10
		int result = 0;
		Random rand = new Random();
		for (int i = 0; i < 1000; i++) {
			int a = rand.nextInt(10) + 1;
			int b = rand.nextInt(10) + 1;
			int c = rand.nextInt(10) + 1;
			result += ((a + b) / c) * ((b - c) / a);
		}
		
		runTime = System.nanoTime() - startTime; // Run Time
		System.out.println("CPU Bound Thread #"+threadNumber+" has ended");
		isFinished = true;
	}
	
	// Returns Run Time
	public long getRunTime() {
		return runTime;
	}
	
	// Returns Boolean Value Representing if Thread is Finished
	public boolean isFinished() {
		return isFinished;
	}
}
