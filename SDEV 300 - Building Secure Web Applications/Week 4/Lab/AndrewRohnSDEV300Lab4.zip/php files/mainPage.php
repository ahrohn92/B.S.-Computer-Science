<!--
Date: Nov 16, 2018 
Author: Andrew H. Rohn  
Title: mainPage.php  
Description: Main Page
-->

<html> 
<!-- PHP Code Checks for Valid User Info -->
<?php
	// Retrieval of User Information
	$userName = $_POST["username"];
	$emailAddress = $_POST["email"];
	$passWord = $_POST["password"];
	
	// Start of Session
	session_start();
	// Expires Session if Inactive for 30 Min
	$expireAfter = 30;
	if(isset($_SESSION['last_action'])){
		$secondsInactive = time() - $_SESSION['last_action'];
		$expireAfterSeconds = $expireAfter * 60;
		if($secondsInactive >= $expireAfterSeconds){
			session_unset();
			session_destroy();
		}
	}
	// User's Latest Activity
	$_SESSION['last_action'] = time();

	// User Session Variables
	$_SESSION['appUserName'] = $userName;
	$_SESSION['appEmailAddress'] = $emailAddress;
	$_SESSION['appPassWord'] = $passWord;
	
	// Checks for Valid Login
	if ($_SESSION['appUserName'] == '' || $_SESSION['appEmailAddress'] == '' || $_SESSION['appPassWord'] == '') {
		include ('loginPage.php');
		?> <p align="center"> <?php echo "Please enter all your user information to login."; ?> </p> <?php
	} else {
?>
<head>    
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">     
	<title>Life Index &trade; - Main Page</title>
</head> 
<body> 
<!-- PHP Code for Main Page -->
<?php
	
	// Array of Image URLs
	$speciesImage = array("https://whyevolutionistrue.files.wordpress.com/2017/03/900-496813583-giant-panda.jpg", 
	"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUiDUcZZ2p0tfucTMeVMgG2N05ufYi8vxLCZG2AyLoYMWTy81t", 
	"https://cdn.audubon.org/cdn/farfuture/txgzOKF1VYrbGeKTgLd5vr6P3Ve97MuvxU3ezTwatL0/mtime:1477671444/sites/default/files/web_apa_2015_karenwilles_282272_whooping_crane_kk.jpg", 
	"http://i.hurimg.com/i/hdn/75/0x0/5a8eb981c9de3d198475cb98.jpg", "https://www.bloemfonteincourant.co.za/wp-content/uploads/2017/09/elephant1.jpg", 
	"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSGx_cd3xTfiiJXgurmEcdVuzuQkXCY1wlA32iZOwNaryPceXcvbQ", 
	"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQGkqvTnBBueLVWGPaUgTeLmCI4TTjr4rZl7ZCnhcHe0wiPKYbT",
	"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQSJ5tajmksLmRM7MI5t9MTENCYqdATMZ72uS6w6NKSr0xB_gIDPA",
	"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRnCftfd9BhG1mvBqubwmcHY-FUV2xODYwDOV2j1jGxK3OyXWk2",
	"https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTapE0UjEpL2Aaaq5jbqcC2WAVW7k3MRQkP0VYBLafn4n9yK2E8pA");
	
	// Array of Endangered Species' Names
	$speciesName = array("Giant Panda", "Tiger", "Whooping Crane", "Blue Whale", "Asian Elephant",
	"Sea Otter", "Snow Leopard", "Gorilla", "Tasmanian Devil", "Orangutan");
	
	// Array of Endangered Species' Binomial Nomenclature
	$binomialNomenclature = array("Ailuropoda melanoleuca", "Panthera tigris", "Grus americana",
	"Balaenoptera musculus", "Elephas maximus", "Enhydra lutris", "Panthera uncia", "Gorilla beringei",
	"Sarcophilus harrisii", "Pongo pygmaeus");
	
	// Array for Genome Map Completion
	$mappingPercent = array(65, 51, 91, 82, 77, 28, 66, 32, 9, 47);

	// Session Arrays
	$_SESSION['appSpeciesImage'] = $speciesImage;
	$_SESSION['appSpeciesName'] = $speciesName;
	$_SESSION['appBinomialNomenclature'] = $binomialNomenclature;
	$_SESSION['appMappingPercent'] = $mappingPercent;
?>

<!-- Main Page -->
<form name='logout' method='post' action='loginPage.php'> 
		<input name='logoutbutton' type='submit' value='Logout'>
</form>
<h2>Welcome <?php echo $userName;?>!</h2>
<br>
<h2>Below is the progress of our genetic mapping efforts. If you have any concerns or questions,
	please leave us your feedback.</h2>
<br>
<form action="summaryPage.php" method="post">
<table border="5">
	<tr>
		<th>Endangered Species</th>
		<th>Genome Map Completion</th>
		<th>Member Feedback</th>
	</tr>
	<?php
	// Table Population w/ Session Variables
	for ($i = 0; $i < 10; $i++) {
	?>
	<tr>
		<td align="center" width="150"><img src="<?php echo $_SESSION['appSpeciesImage'][$i]; ?>" width="150" height="100"/>
			<br><br><?php echo $_SESSION['appSpeciesName'][$i]; ?>
			<br><br><i>(<?php echo $_SESSION['appBinomialNomenclature'][$i]; ?>)</i></td>
		<td align="center" width="150"><?php echo $_SESSION['appMappingPercent'][$i]; ?>%</td>
		<td><textarea name="comment_<?php echo $i; ?>" style="width:400px; height:195px;"> </textarea></td>
	</tr>
	<?php
	}
	?>
	<tr></tr>
	<tr>
		<td colspan="3" align="center"><br><input name="submitbutton" type="submit" value="Submit">
			<input name="resetbutton" type="reset" value="Reset"><br><br></td> 
	</tr>
</table>
</form>
</body>
<?php
	}
?>
</html>