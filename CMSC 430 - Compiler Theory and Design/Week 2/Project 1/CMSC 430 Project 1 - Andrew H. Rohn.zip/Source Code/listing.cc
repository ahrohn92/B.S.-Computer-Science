/*
 * Course:  	CMSC 430
 * File: 		listing.cc
 * Author: 		Andrew H. Rohn
 * Date: 		14 June 2019
 * Purpose: 	This file displays the type and quantity of any compilation errors that occur.
 * 				This file also contains the bodies of the functions that produces the compilation listing.
 */

#include <cstdio>
#include <string>

using namespace std;

#include "listing.h"

static int lineNumber;
static string error = "";
static int totalErrors = 0;
static int lexicalErrors = 0;
static int syntaxErrors = 0;
static int semanticErrors = 0;

static void displayErrors();

void firstLine()
{
	lineNumber = 1;
	printf("\n%4d  ",lineNumber);
}

void nextLine()
{
	displayErrors();
	lineNumber++;
	printf("%4d  ",lineNumber);
}

int lastLine()
{
	printf("\r");
	displayErrors();
	printf("     \n");
	
	if (totalErrors == 0) {
		printf("Compiled Successfully");
	} else {
		printf("Lexical Errors %d\n", lexicalErrors);
		printf("Syntax Errors %d\n", syntaxErrors);
		printf("Semantic Errors %d\n", semanticErrors);
		printf("Total Errors %d", totalErrors);
	}

	return totalErrors;
}
    
void appendError(ErrorCategories errorCategory, string message)
{
	string messages[] = { "Lexical Error, Invalid Character: ", "Syntax Error: ",
		"Semantic Error: ", "Semantic Error, Duplicate Identifier: ",
		"Semantic Error, Undeclared: " };

	error += messages[errorCategory] + message + "\n";
	
	// Tallies Different Types of Errors
	switch(errorCategory) {
			case 0 : lexicalErrors++;
				break;
			case 1 : syntaxErrors++;
				break;
			case 2 : semanticErrors++;
				break;
			case 3 : semanticErrors++;
				break;
			case 4 : semanticErrors++;
				break;
			default :
				break;
	}
	totalErrors++;
}

void displayErrors()
{
	if (error != "")
		printf("%s\n", error.c_str());
	error = "";
}
