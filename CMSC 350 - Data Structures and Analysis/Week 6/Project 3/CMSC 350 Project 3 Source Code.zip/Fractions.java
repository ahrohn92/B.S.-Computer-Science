/*
 * Course:  	CMSC 350
 * File: 	Fractions.java
 * Author: 	Andrew H. Rohn
 * Date: 	1 December 2018
 * Purpose: 	Contains a constructor that defines a fraction by accepting a string representation
 * 		of a fraction, finds its value for sorting with a compareTo method, and returns the
 * 		fraction via a toString method.
 */

public class Fractions implements Comparable<Fractions> {

	// Instance Variables for Defining Fractions
    private double numerator;
    private double denominator;
    private double value;

    // Constructor for Fractions
    Fractions(String fraction) throws NumberFormatException {

    	// Splits Fraction into Numerator and Denominator
        String[] numbers = fraction.split("/");
        
        // Defines First Number as Numerator and Second Number as Denominator
        numerator = Double.parseDouble(numbers[0]);
        denominator = Double.parseDouble(numbers[1]);

        // Throws NumberFormatException if Fraction is not Properly Formatted
        // with one Numerator and one Denominator
        if (numbers.length != 2) throw new NumberFormatException(fraction);
        
        // Throws NumberFormatException if Denominator is 0
        if (denominator == 0) throw new NumberFormatException(fraction);

        // Determines Value of Fraction for Sorting
        value = numerator / denominator;
    }

    // Method that Determines Order of Fractions for Sorting
    public int compareTo(Fractions fraction) {
        if (this.value > fraction.value) {
            return 1;
        } else if (this.value == fraction.value) {
        	return 0;
        } else {
        	return -1;
        }
    }
    
    // Returns Fraction as a String
    public String toString() {
        return (int)numerator+"/"+(int)denominator;
    }
}