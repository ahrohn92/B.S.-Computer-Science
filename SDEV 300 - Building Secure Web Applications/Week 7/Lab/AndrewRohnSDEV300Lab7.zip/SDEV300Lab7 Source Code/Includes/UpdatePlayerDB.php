<?php
// Connects to Wamp Database
include_once 'Includes/connectDB.php';

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}	

// Sanitizes Strings
$oldUserName = mysqli_real_escape_string($conn, $_SESSION['appUserName']);
$newUserName = mysqli_real_escape_string($conn, $newUserName);
$newPassWord = mysqli_real_escape_string($conn, $newPassWord);

// Prepared Statement Checks if New Username is Original
$sql_1 = "SELECT * FROM players WHERE Username=?;";
$stmt = $conn->prepare($sql_1);			
$stmt->bind_param("s", $newUserName);
$stmt->execute();

//Clean-up				
$stmt->close(); 

// Prepared Statement Checks if New Password is Original
$sql_2 = "SELECT * FROM players WHERE Password=?;";
$stmt = $conn->prepare($sql_2);			
$stmt->bind_param("s", $newPassWord);
$stmt->execute();

//Clean-up				
$stmt->close();

if (mysqli_num_rows(mysqli_query($conn, $sql_1)) > 0) {
	$uniqueUserCheck = false;
	
} else if (mysqli_num_rows(mysqli_query($conn, $sql_2)) > 0) {
	$uniquePassCheck = false;
	
} else {
	// Prepared Statement Updates User's Username and Password
	$sql_3 = "UPDATE players SET Username=?,Password=? WHERE Username=?;";
	$stmt = $conn->prepare($sql_3);			
	$stmt->bind_param("sss", $newUserName, $newPassWord, $oldUserName);
	$stmt->execute();

	//Clean-up				
	$stmt->close();
	
	$uniqueUserCheck = true;
	$uniquePassCheck = true;
}

// Sanitizes Strings
$que_0 = mysqli_real_escape_string($conn, $que_0);
$ans_0 = mysqli_real_escape_string($conn, $ans_0);
$que_1 = mysqli_real_escape_string($conn, $que_1);
$ans_1 = mysqli_real_escape_string($conn, $ans_1);
$que_2 = mysqli_real_escape_string($conn, $que_2);
$ans_2 = mysqli_real_escape_string($conn, $ans_2);

// Prepared Statement Update Security Questions
$sql_4 = "UPDATE securityquestions SET Username=?,SecurityQuestion_1=?,
SecurityAnswer_1=?,SecurityQuestion_2=?,SecurityAnswer_2=?,
SecurityQuestion_3=?,SecurityAnswer_3=? WHERE Username=?;";
	
$stmt = $conn->prepare($sql_4);			
$stmt->bind_param("ssssssss", $newUserName, $que_0, $ans_0, $que_1, $ans_1, $que_2, $ans_2, $oldUserName);
$stmt->execute();

//Clean-up				
$stmt->close();

// Closes Connection to Database
mysqli_close($conn);
?>