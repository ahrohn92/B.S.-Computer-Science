/*
 * Course:  	CMSC 350
 * File: 		OperandNodes.java
 * Author: 		Andrew H. Rohn
 * Date: 		18 November 2018
 * Purpose: 	Creates the operand nodes used in the arithmetic expression tree
 */

public class OperandNodes implements TreeNodes {

    private String operandNode;

    // Localizes operand value
    OperandNodes(String operandNode) {
        this.operandNode = operandNode;
    }

    // Traverses operand nodes in Inorder
    public String traverseInOrder() {
        return String.valueOf(operandNode);
    }

    // Traverses operand nodes in Postorder
    public String traversePostOrder() {
        return String.valueOf(operandNode);
    }

    // Initiates new post order traversal
    public void newTraversal() {}
}