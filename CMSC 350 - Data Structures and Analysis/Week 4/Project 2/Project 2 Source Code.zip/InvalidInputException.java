/*
 * Course:  	CMSC 350
 * File: 		InvalidInputException.java
 * Author: 		Andrew H. Rohn
 * Date: 		18 November 2018
 * Purpose: 	Contains InvalidInputException exception constructor.
 */

class InvalidInputException extends Exception {

    public InvalidInputException(String token) {
        super(token);
    }
}