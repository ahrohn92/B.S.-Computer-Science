import java.util.*;
import java.util.regex.Pattern;
import java.io.IOException;

/*
 * Course:  	CMSC 350
 * File: 		PostToInfix.java
 * Author: 		Andrew H. Rohn
 * Date: 		18 November 2018
 * Purpose: 	Separates postfix expression into tokens that are pushed onto a stack
 */

public class PostToInfix {

    // Instance Variables
	private TreeNodes operator;
    private Stack<TreeNodes> expStack = new Stack<>();
    
    String postfixExpEval(String postfixExp) throws EmptyStackException, InvalidInputException, IOException {
    	
    	// tokenizes of string containing the expression
	    List<String> tokens = tokenize(postfixExp);

        for (String token : tokens) {
        	
        	// Patterns used to determine if token is an operand or operator
    	    Pattern operandPattern = Pattern.compile("[\\d.?]");
    	    Pattern operatorPattern = Pattern.compile("[+*/\\-]");

    	    // Throws InvalidInputException if token is not an operand, operator, or parenthesis
            if (!token.matches(String.valueOf(operandPattern))
		    		&& !token.matches(String.valueOf(operatorPattern))
		    		&& !token.equals("(")
		    		&& !token.equals(")")) {
		        		throw new InvalidInputException(token);
		     }

            // Pushes operand onto stack
            if (token.matches(String.valueOf(operandPattern))) {
            	expStack.push(new OperandNodes(token));
            // Pairs operands with operator and pushes operator onto stack
            } else if (token.matches(String.valueOf(operatorPattern))) {
                operator = new OperatorNodes(token, expStack.pop(), expStack.pop());
                expStack.push(operator);
            }
        }

        // Creates the Assembly Code written to File
        operator.newTraversal();

        return expStack.pop().traverseInOrder();
    }
    
    // Method that Tokenizes PostfixExp
 	private List<String> tokenize(String postfixExp) {

 	    // Initialization of tokenArrayList
 	    List<String> tokenArrayList = new ArrayList<>();

 	    // Adds first character of string to tokenArrayList
 	    tokenArrayList.add(Character.toString(postfixExp.charAt(0)));

 	    // Tokenizes rest of string
 	    for (int i = 1; i < postfixExp.length(); i++) {

 	    	// Ignores Spaces in String
 	    	if (postfixExp.charAt(i) == ' ') {
 		        continue;
 		    }
 	    	
 	    	// Checks to see if characters are digits
 	    	// If so, they are combined into single token
 	    	char prevChar = postfixExp.charAt(i-1);
 	    	char currentChar = postfixExp.charAt(i);

 	    	if (Character.isDigit(prevChar) && Character.isDigit(currentChar)) {
 	    		int prevIndex = (tokenArrayList.size()-1);
 	    		tokenArrayList.set(prevIndex, tokenArrayList.get(prevIndex) + currentChar);
 	    		
 	    	// else, added as separate token
 	    	} else {
 	    		tokenArrayList.add(Character.toString(currentChar));
 	    	}
 	    }
 	    return tokenArrayList;
 	}
}
