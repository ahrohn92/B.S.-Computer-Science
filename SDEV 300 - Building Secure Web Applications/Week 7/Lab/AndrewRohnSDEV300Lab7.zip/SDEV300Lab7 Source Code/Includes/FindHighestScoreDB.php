<?php

// Connects to Wamp Database
$sqlServerName = "localhost";
$sqlUserName = "wamp_user";
$sqlPassWord = "user4wamp";
$sqlDB = "wamp";

// Creates Connection with mysql
$conn = mysqli_connect($sqlServerName, $sqlUserName, $sqlPassWord, $sqlDB);

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}

// Fetches Username and HighScore with the Highest Score
$array = array(2);

$sql = "SELECT Username, HighScore FROM players WHERE HighScore = (SELECT MAX(HighScore) FROM players);";

$result = mysqli_query($conn, $sql) or die(mysqli_error());

	while ($row = mysqli_fetch_assoc($result)) {
		$array[0] = $row['Username'];
		$array[1] = $row['HighScore'];
	}	
	
$userHighScore = $array[0];
$highScore = $array[1];

// Closes Connection to Database
mysqli_close($conn);
?>