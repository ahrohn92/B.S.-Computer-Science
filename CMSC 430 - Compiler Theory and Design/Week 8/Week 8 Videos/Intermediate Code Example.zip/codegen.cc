#include <iostream>
#include <fstream>
#include <sstream>
#include <string>
#include <cstring>
#include <cstdlib>

using namespace std;

#include "codegen.h"

static string opSymbols[] = { " < ", " + ", " * ", " & " };
static int nextTemp = 1;
static int quadrupleNo = 1;
static ofstream	quadFile("quads.txt");

CharPtr emit(Operators opCode, CharPtr left, CharPtr right)
{
	stringstream temp;
	temp << "T" << nextTemp++;;
	string tempStr = temp.str();
	CharPtr result = (CharPtr)malloc(tempStr.length()); 
	strcpy(result, tempStr.c_str());
	quadFile << quadrupleNo++ << " " << result << " = " << left << opSymbols[opCode] << 
		right << endl;
	return result;
}

