import java.util.*;

/*
 * Course:  	CMSC 350
 * File: 		IndexStack.java
 * Author: 		Andrew H. Rohn
 * Date: 		15 December 2018
 * Purpose: 	This class creates a stack data structure, from which vertex indices can be pushed or popped,
 *				in order to sort the vertices in topological order.
 */

public class IndexStack<Integer> {
	
	// Instance Variables for Stack Data Structure
	private ArrayList<Integer> indices; 
	private int numIndices;
	
	// Constructor for Stack
	public IndexStack() {
		indices = new ArrayList<Integer>();
		numIndices = 0;
	}
	
	// Adds New Index Onto Stack
	public void pushIndex(Integer index) {
		indices.add(index);
		numIndices++;
	} 
	
	// Returns Most Recent Index on Top of Stack
	public Object popIndex() {
		if (numIndices != 0) {
			int recentIndex = (int) indices.get(indices.size() - 1);
			indices.remove(indices.size() - 1);
			numIndices--;
			return recentIndex;
		} else {
			return null;
		}	
	}
	
	// Checks if Stack is Not Empty
	public boolean notEmpty() {
		if (numIndices != 0) {
			return true;
		} else {
			return false;
		}	
	}
}