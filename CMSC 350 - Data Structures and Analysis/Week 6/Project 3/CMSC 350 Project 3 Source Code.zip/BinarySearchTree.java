/*
 * Course:  	CMSC 350
 * File: 	BinarySearchTree.java
 * Author: 	Andrew H. Rohn
 * Date: 	1 December 2018
 * Purpose: 	Contains a method to initialize binary search tree (BST), a method to insert new values
 * 		into the BST, and a method that performs an inorder tree traversal that generates and
 * 		returns a string that contains the tree elements in sorted order.
 */

class BinarySearchTree <T extends Comparable<T>> {

    // Instance Variables for Binary Search Tree
    private Node rootNode;
    private StringBuilder sortedList = new StringBuilder();

    // Constructor that Initializes Binary Search Tree
    BinarySearchTree() {
        rootNode = null;
        sortedList.setLength(0);
    }
    
    // Defines a Node
    class Node {

        // Instance Variables
        private T value;
        private Node leftNode, rightNode;

        // Methods for Checking Values of Left and Right Nodes
        Node(T value) {
            this.value = value;
            this.leftNode = null;
            this.rightNode = null;
        }
        Node checkLeftNode() {
            return leftNode;
        }
        Node checkRightNode() {
            return rightNode;
        }
    }
    
    // Creates a New Node in BST and Inserts Value into Node
    void newNode (T currentNode) {
    	
    	// If There is No Root Node, New Node Becomes Root Node
        if (rootNode == null) {
        	rootNode = new Node(currentNode);
            return;
        }
        
        // Calls Method to Insert New Node Recursively
        insertNewNode(currentNode, rootNode);
    }

    // Method that Inserts a New Node into the Binary Search Tree Recursively
    // and Checks to See if Values in Nodes are Sorted Correctly
    private void insertNewNode(T currentNode, Node previousNode) {
    	
    	// If the Current Node is <= the Previous Node
        if (currentNode.compareTo(previousNode.value) <= 0) {
        	
        	// If the Left Node is not Empty
            if (previousNode.leftNode != null) {
            	
            	// New Values are Inserted Recursively into Current and Previous Nodes
            	insertNewNode(currentNode, previousNode.leftNode);
            	
            // Else, Current Node is Inserted to the Left of the Previous Node
            } else {
            	previousNode.leftNode = new Node(currentNode);
            }
            
        // Else if, the Current Node is > the Previous Node
        } else if (currentNode.compareTo(previousNode.value) > 0) {
        	
        	// If the Right Node is not Empty
            if (previousNode.rightNode != null) {
            	
            	// New Values are Inserted Recursively into Current and Previous Nodes
            	insertNewNode(currentNode, previousNode.rightNode);
            	
            // Else, Current Node is Inserted to the Right of the Previous Node
            } else {
            	previousNode.rightNode = new Node(currentNode);
            }
        }
    }

    // Inorder Traversal of Binary Search Tree to Sort Elements in Order
    private void inorderTreeTraversal(Node rootNode) {
    	
    	// If Root Node is not Empty
        if (rootNode.value != null) {
        	
        	// If Left Node is not Empty, the Next Left Node is Checked Until There is an Empty Left Node
            if (rootNode.checkLeftNode() != null) inorderTreeTraversal(rootNode.checkLeftNode());

            // Root Node is Added to Sorted List
            String rootNodeValue = (rootNode.value).toString();
            sortedList.append(rootNodeValue).append(" ");
            
            // If Right Node is not Empty, the Next Right Node is Checked Until There is an Empty Right Node
            if (rootNode.checkRightNode() != null) inorderTreeTraversal(rootNode.checkRightNode());
        }
    }
    
    // Returns String in Ascending Sort Order w/ Inorder Traversal method
    String ascendingOrder() {
    	inorderTreeTraversal(rootNode);
        return sortedList.toString();
    }

    // Returns String in Descending Sort Order by Reversing Ascending Sort Order
    String descendingOrder() {
    	
        // Splits Ascending Sort Order into an Array of Strings
    	ascendingOrder();
        String[] numericValues = sortedList.toString().split(" ");
        
        // Sorted List StringBuilder is Reset, to be Built in Reverse
        sortedList.setLength(0);
        for (int i = numericValues.length - 1; i >= 0; i--) {
        	sortedList.append(numericValues[i]).append(" ");
        }
        return sortedList.toString();
    }
}