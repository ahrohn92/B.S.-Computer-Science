import com.jogamp.opengl.*;
import com.jogamp.opengl.awt.GLJPanel;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.text.DecimalFormat;

/*
 * Course:  	CMSC 405
 * File: 		CMSC405P2.java
 * Author: 		Andrew H. Rohn
 * Date: 		29 June 2019
 * Purpose: 	This class initializes OpenGL to render 3D shapes called from the Shapes class. It also contains
 * 				a KeyListener to allow the user to make transformations to the 3D shapes via keyboard.
 */

public class CMSC405P2 extends GLJPanel implements GLEventListener, KeyListener {
	
	// Dimensions
	private static int WIDTH = 640;
	private static int HEIGHT = 480;
	
    // Initial Transformational Data
	private double translateX = 0;
	private double translateY = 0;
	private double translateZ = 0;
	private double rotateX = 30;
	private double rotateY = -30;
	private double rotateZ = 0;
	private double scale = 1.0;
	
	// Class Objects
	Shapes shapes;
	GL2 gl;
	
	// Decimal Formatting for Print Statements
	DecimalFormat df = new DecimalFormat("0.0##");
	
	// Constructor
	private CMSC405P2() {
		super(new GLCapabilities(null));
	    setMinimumSize(new Dimension(WIDTH, HEIGHT));
	    addGLEventListener(this);
	    addKeyListener(this);
	    shapes = new Shapes();
	}

	// Redraws Panel After Transformation
	public void display(GLAutoDrawable drawable) {

		// OpenGL Class Object
		gl = drawable.getGL().getGL2();
		gl.glClear(GL2.GL_COLOR_BUFFER_BIT | GL2.GL_DEPTH_BUFFER_BIT);
	    gl.glLoadIdentity();
	    
	    // Updates Transformational Data
	    gl.glTranslated(translateX, translateY, translateZ);
	    gl.glRotated(rotateX, 1, 0, 0);
	    gl.glRotated(rotateY, 0, 1, 0);
	    gl.glRotated(rotateZ, 0, 0, 1);
	    gl.glScaled(scale, scale, scale);

	    // Draw Shapes After Transformation
	    renderShape(shapes.verticesList.get(0), shapes.facesList.get(0), shapes.colorList.get(0), 0, 0, 1.5, 0.225);
	    renderShape(shapes.verticesList.get(1), shapes.facesList.get(1), shapes.colorList.get(1), 0, 0, -1.5, 0.225);
	    renderShape(shapes.verticesList.get(2), shapes.facesList.get(2), shapes.colorList.get(2), 2.5, 0, 1.5, 0.225);
	    renderShape(shapes.verticesList.get(3), shapes.facesList.get(3), shapes.colorList.get(3), -2.5, 0, -1.5, 0.225);
	    renderShape(shapes.verticesList.get(4), shapes.facesList.get(4), shapes.colorList.get(4), 2.5, 0, -1.5, 0.225);
	    renderShape(shapes.verticesList.get(5), shapes.facesList.get(5), shapes.colorList.get(5), -2.5, 0, 1.5, 0.225);
	}

	@Override
	// Initial OpenGL Parameters
	public void init(GLAutoDrawable drawable) {
		GL2 gl = drawable.getGL().getGL2();
		gl.glMatrixMode(GL2.GL_PROJECTION);
	    gl.glOrtho(-1, 1, -1, 1, -1, 1);
	    gl.glMatrixMode(GL2.GL_MODELVIEW);
	    gl.glClearColor(0, 0, 0, 1);
	    gl.glEnable(GL2.GL_DEPTH_TEST);
	    gl.glLineWidth(2);
	    
	    // Prints Initial Transformational Data
	    printTransData();
	}

	@Override
	// Key Binding for Transformations
	public void keyPressed(KeyEvent evt) {
		switch(evt.getKeyCode()) {
			case KeyEvent.VK_W: translateY += 0.05;
				System.out.println("The shapes were translated +0.05 along the y-axis.\n");
				break;
			case KeyEvent.VK_A: translateX -= 0.05;
				System.out.println("The shapes were translated -0.05 along the x-axis.\n");
				break;
			case KeyEvent.VK_S: translateY -= 0.05;
				System.out.println("The shapes were translated -0.05 along the y-axis.\n");
				break;
			case KeyEvent.VK_D: translateX += 0.05;
				System.out.println("The shapes were translated +0.05 along the x-axis.\n");
				break;
			case KeyEvent.VK_LEFT: rotateY -= 7.5;
				System.out.println("The shapes were rotated -7.5 along the y-axis.\n");
				break;
			case KeyEvent.VK_RIGHT: rotateY += 7.5;
				System.out.println("The shapes were rotated +7.5 along the y-axis.\n");
				break;
			case KeyEvent.VK_UP: rotateX -= 7.5;
				System.out.println("The shapes were rotated -7.5 along the x-axis.\n");
				break;
			case KeyEvent.VK_DOWN: rotateX += 7.5;
				System.out.println("The shapes were rotated +7.5 along the x-axis.\n");
				break;
			case KeyEvent.VK_PLUS: scale += 0.1;
				System.out.println("The shapes were scaled by +0.1.\n");
				break;
			case KeyEvent.VK_EQUALS: scale += 0.1;
				System.out.println("The shapes were scaled by +0.1.\n");
				break;
			case KeyEvent.VK_MINUS: scale -= 0.1;
				System.out.println("The shapes were scaled by -0.1.\n");
				break;
			case KeyEvent.VK_ESCAPE:
				translateX = 0;
				translateY = 0;
				translateZ = 0;
				rotateX = 30;
				rotateY = -30;
				rotateZ = 0;
				scale = 1.0;
				System.out.println("The shapes were transformed to original positions.\n");
				break;
			default:
				break;
		}
		printTransData();
		repaint();
	}

	// Renders Shapes
	private void renderShape(double[][] vertices, int[][] faces, Color color,
			double translateX, double translateY, double translateZ, double scale) {

	    gl.glPushMatrix();
	    gl.glScaled(scale, scale, scale);
	    gl.glTranslated(translateX, translateY, translateZ);
	
	    for (int i = 0; i < faces.length; i++) {
	    	gl.glPushMatrix();
	      
	     	// Fills in Faces of Shapes with Color
	    	gl.glColor3d(color.getRed(), color.getGreen(), color.getBlue());
	    	gl.glBegin(GL2.GL_TRIANGLE_FAN);
	
	    	for (int j = 0; j < faces[i].length; j++) {
	    		int faceVertex = faces[i][j];
	    		gl.glVertex3dv(vertices[faceVertex], 0);
	    	}
	    	gl.glEnd();
	
	    	// Draws Edges of Shapes Black
	    	gl.glColor3d(0, 0, 0);
	    	gl.glBegin(GL2.GL_LINE_LOOP);
	    	for (int j = 0; j < faces[i].length; j++) {
	    		int faceVertex = faces[i][j];
	    		gl.glVertex3dv(vertices[faceVertex], 0);
	    	}
	    	gl.glEnd();
	    	gl.glPopMatrix();
	    }
	    gl.glPopMatrix();
	}
	
	// Prints Transformational Data for Testing
	private void printTransData() {
		System.out.println("TRANSFORMATIONAL DATA:");
		System.out.println("Translate X: "+df.format(translateX));
		System.out.println("Translate Y: "+df.format(translateY));
		System.out.println("Translate Z: "+df.format(translateZ));
		System.out.println("Rotation X: "+df.format(rotateX));
		System.out.println("Rotation Y: "+df.format(rotateY));
		System.out.println("Rotation Z: "+df.format(rotateZ));
		System.out.println("Scale: "+df.format(scale)+"\n\n");
	}
	
	@Override
	// Default GLEventListener Method
	public void dispose(GLAutoDrawable drawable) {}
	  
	@Override
  	//Default GLEventListener Method
  	public void reshape(GLAutoDrawable drawable, int x, int y, int width, int height) {}
  
  	@Override
  	// Default KeyListener Method
  	public void keyReleased(KeyEvent evt) {}

  	@Override
  	// Default KeyListener Method
  	public void keyTyped(KeyEvent evt) {}
  	
  	// Main Method
	public static void main(String[] args) {
		
		CMSC405P2 main = new CMSC405P2();
	    JFrame frame = new JFrame();
	    
	    frame.setMinimumSize(main.getMinimumSize());
	    frame.setTitle("CMSC 405 Project 2");
	    frame.setContentPane(main);
	    frame.setLocationRelativeTo(null);
	    frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	    frame.setVisible(true);
	}
}