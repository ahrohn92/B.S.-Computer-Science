<?php

// Variables
$numAnsweredSelectedQuestions = 0;
$securityAnswers = array(10);
$selectedSecurityQuestions = array(10);

$securityQuestionsDB = array(3);
$securityAnswersDB = array(3);

// Determines that 3 security questions were selected
if (count($_POST["securityquestions"]) != 3) {
	$sqCheck_1 = false;
} else {
	$sqCheck_1 = true;
}	
			
// Saves Selected Security Questions and Answers in Arrays
for ($i = 0; $i < 10; $i++) {
	$selectedSecurityQuestions[$i] = $_POST['securityquestions'][$i];
	$securityAnswers[$i] = $_POST["answer_".$i.""];
	
	// Determines if Selected Questions has an Answer
	if ($selectedSecurityQuestions[$i] != '' && $securityAnswers[$i] != '') {
		$numAnsweredSelectedQuestions++;
	}
}	

if ($numAnsweredSelectedQuestions != 3) {
	$sqCheck_2 = false;
} else {
	$sqCheck_2 = true;
}	

$n = 0;
$m = 0;

// Removes elements from arrays that have no value		
for ($i = 0; $i < 10; $i++) {
	if ($selectedSecurityQuestions[$i] != '') {
		$securityQuestionsDB[$n] = $selectedSecurityQuestions[$i];
		$n++;
	}	
	if ($securityAnswers[$i] != '') {
		$securityAnswersDB[$m] = $securityAnswers[$i];
		$m++;
	}
}	

// Splits Arrays into Variables
extract($securityQuestionsDB, EXTR_PREFIX_ALL, "que");
extract($securityAnswersDB, EXTR_PREFIX_ALL, "ans");
		
?>