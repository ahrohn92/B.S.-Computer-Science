<!--
Date: Nov 16, 2018 
Author: Andrew H. Rohn  
Title: summaryPage.php  
Description: Summary Page
-->

<html> 
<head>    
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">    
	<title>Life Index &trade; - Summary Page</title>
</head> 
<body>
<form name='logout' method='post' action='loginPage.php'>  
	<input name='logoutbutton' type='submit' value='Logout'>  
</form>
<?php
// Timestamp
date_default_timezone_set("America/New_York");
$t = time();
// Session Start
session_start();
// Expires Session if Inactive for 30 Min
$expireAfter = 30;
if(isset($_SESSION['last_action'])){
    $secondsInactive = time() - $_SESSION['last_action'];
    $expireAfterSeconds = $expireAfter * 60;
    if($secondsInactive >= $expireAfterSeconds){
        session_unset();
        session_destroy();
    }
}
// User's Latest Activity
$_SESSION['last_action'] = time();
?>
 
<h2>Thank you <?php echo $_SESSION['appUserName']; ?>!<br>
	We have logged your feedback and will review it as soon as possible.</h2>
<br>
<h2>Here is a summary of your feedback:</h2>
<p><i>Submitted: <?php echo date("m-d-Y  @  h:i:sa", $t); ?></i></p>
<table border="5">
	<tr>
		<th>Endangered Species</th>
		<th>Genome Map Completion</th>
		<th>Member Feedback</th>
	</tr>
	<?php
	$memberFeedback = array(10);
	
	for ($i = 0; $i < 10; $i++) {
		$memberFeedback[$i] = htmlspecialchars($_POST["comment_".$i.""]); 
	}	
	// Table Population
	for ($i = 0; $i < 10; $i++) {
	?>
	<tr>
		<td align="center" width="150"><img src="<?php echo $_SESSION['appSpeciesImage'][$i]; ?>" width="150" height="100"/>
			<br><br><?php echo $_SESSION['appSpeciesName'][$i]; ?>
			<br><br><i>(<?php echo $_SESSION['appBinomialNomenclature'][$i]; ?>)</i></td>
		<td align="center" width="150"><?php echo $_SESSION['appMappingPercent'][$i]; ?>%</td>
		<td align="center" width="400" height="185"><?php echo $memberFeedback[$i]; ?></td>
	</tr>
	<?php
	}
	?>
</table>
</body> 
</html>