<!--
Date: Nov 16, 2018 
Author: Andrew H. Rohn  
Title: loginPage.php  
Description: Login Page
-->

<!DOCTYPE html>
<html>
<?php 
// Deletes User Session Variables When Logged Out
session_start(); 
unset($_SESSION['appUserName']); 
unset($_SESSION['appEmailAddress']); 
unset($_SESSION['appPassWord']); 
?> 
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
	<title>Life Index &trade; - Login Page</title>
</head>
<body OnLoad="document.main.username.focus();"> 
	<h1 align="center">Welcome to Life Index!<h1>
	<br>
	<center>
		<img align="middle" src="https://www.forlifeonearth.org/wp-content/uploads/2014/08/slide-2.jpg" width="800" height="350"/>
	</center>
	<br>
	<h2 align="center">Here at Life Index &trade;, it is our continuing mission to map the genome of endangered species so that in the case
		of extinction, we can resurrect these majestic creatures.</h2>
	</br>	
	<p align="center">To see the progress of our genetic mapping and to leave feedback, please login.</p>
	<br>
	<form name="main" method="post" action="mainPage.php">  
	<table align="center">
		<tr>
			<th>Username:</th>
			<td><input name="username" type="text" size="50"></td>
		</tr>
		<tr>
			<th>Email Address:</th>
			<td><input name="email" type="text" size="50"></td>
		</tr>
		<tr>
			<th>Password:</th>
			<td><input name="password" type="text" size="50"></td>
		</tr>
		<tr>
			<td colspan="2" align="center"><input name="submitbutton" type="submit" value="Login">
			<input name="resetbutton" type="reset" value="Reset"></td> 
		</tr>
	</table>
</body>
</html>