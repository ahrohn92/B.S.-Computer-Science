<?php

$sqlServerName = "localhost";
$sqlUserName = "wamp_user";
$sqlPassWord = "user4wamp";
$sqlDB = "wamp";

// Creates Connection with mysql
$conn = mysqli_connect($sqlServerName, $sqlUserName, $sqlPassWord, $sqlDB);

// Checks Connection to Database
if ($conn->connect_error) {
	die("Connection failed: ".$conn->connect_error);
}

// Sanitize Strings
$userName = $_SESSION['appUserName'];
$userName = mysqli_real_escape_string($conn, $userName);
$score = mysqli_real_escape_string($conn, $score);

// Prepared Update Statement
$sql = "UPDATE players SET HighScore=? WHERE Username=?;";
$stmt = $conn->prepare($sql);			
$stmt->bind_param("ss", $score, $userName);
$stmt->execute();

//Clean-up				
$stmt->close(); 
// Closes Connection to Database
mysqli_close($conn);
?>