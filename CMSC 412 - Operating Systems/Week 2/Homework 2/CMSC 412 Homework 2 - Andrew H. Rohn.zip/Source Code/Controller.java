import java.text.DecimalFormat;
import java.util.ArrayList;

/*
 * Course:  	CMSC 412
 * File: 		Controller.java
 * Author: 		Andrew H. Rohn
 * Date: 		1 Sep 2019
 * Purpose: 	This class creates 5 IOBound & 5 CPUBound class objects, creates threads for each, and starts the threads concurrently.
 * 				Once all the threads are finished, the run time of each thread and the program are printed in the console.
 */

public class Controller {
	
	// ArrayLists of Class Objects
	private static ArrayList<IOBound> ioObjects = new ArrayList<IOBound>();
	private static ArrayList<CPUBound> cpuObjects = new ArrayList<CPUBound>();

	// Local Variables
	private boolean run = true;
	private static long startTime;
	private long runTime;
	
	// Constructor
	public Controller() {
		
		// Instantiates 5 IOBound and 5 COUBound Objects
		for (int i = 1; i <= 5; i++) {
			ioObjects.add(new IOBound(i));
			cpuObjects.add(new CPUBound(i));
		}
	}
	
	// Prints Results
	private void printResults() {

		// Waits for All Threads To Complete Before Printing Results
		while (run) {
			run = !threadsAreComplete();
		}
		
		// Calculates Total Run Time of Program
		runTime = System.nanoTime() - startTime;
		
		// Formats Results for Output to Console
		System.out.println("\n----------RESULTS----------\n");
		DecimalFormat df = new DecimalFormat("0.000");
		for (int i = 0; i < 5; i++) {
			System.out.println("Run Time of IO Bound Thread #"+(i+1)+": "+df.format(ioObjects.get(i).getRunTime()/1000000.0)+" ms");
		}
		for (int i = 0; i < 5; i++) {
			System.out.println("Run Time of CPU Bound Thread #"+(i+1)+": "+df.format(cpuObjects.get(i).getRunTime()/1000000.0)+" ms");
		}
		System.out.println("\nRun Time of Program: "+df.format(runTime/1000000.0)+" ms");
	}
	
	// Checks to See if All Threads Are Complete
	private boolean threadsAreComplete() {
		for (int i = 0; i < 5; i++) {
			if (!ioObjects.get(i).isFinished() || !cpuObjects.get(i).isFinished()) {
				return false;
			}
		}
		return true;
	}
	
	// Main Method
	public static void main(String args[]) {
		
		// Starts Program Run Time
		startTime = System.nanoTime();
		
		Controller main = new Controller();
		
		// Creates IOBound Threads
		Thread ioThreadOne = new Thread(ioObjects.get(0));
		Thread ioThreadTwo = new Thread(ioObjects.get(1));
		Thread ioThreadThree = new Thread(ioObjects.get(2));
		Thread ioThreadFour = new Thread(ioObjects.get(3));
		Thread ioThreadFive = new Thread(ioObjects.get(4));
		
		// Creates CPUBound Threads
		Thread cpuThreadOne = new Thread(cpuObjects.get(0));
		Thread cpuThreadTwo = new Thread(cpuObjects.get(1));
		Thread cpuThreadThree = new Thread(cpuObjects.get(2));
		Thread cpuThreadFour = new Thread(cpuObjects.get(3));
		Thread cpuThreadFive = new Thread(cpuObjects.get(4));
		
		// Starts Threads
		ioThreadOne.start();
		ioThreadTwo.start();
		ioThreadThree.start();
		ioThreadFour.start();
		ioThreadFive.start();
		cpuThreadOne.start();
		cpuThreadTwo.start();
		cpuThreadThree.start();
		cpuThreadFour.start();
		cpuThreadFive.start();
		
		// Prints Results
		main.printResults();
	}
}
